package com.fran.ordenaciones;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Hello world!
 *
 */
public class Ordenaciones 
{
    public static void main( String[] args )
    {
    	eOrdenaciones();
    }
    
    public static void eOrdenaciones() {
    	// a, A, á
    	// Diferencia primaria: a, b son diferentes
    	// Diferencia secundaria: a, á son diferentes (tildes)
    	// Diferencia terciaria: a, A son diferentes (case Sensitive)
    	
    	List<String> provincias = List.of("Alicante", "málaga", "Álava", "alava","Alava","Valencia","álava","Àlava","älava");
    	
    	// Pasar lista -> Array
    	String[] provinciasArray = (String[])provincias.toArray(new String[0]);
    	Arrays.sort(provinciasArray);
    	System.out.println("*** Sort de Arrays.sort ***");
    	for(int i = 0;i<provinciasArray.length;i++) {
    		System.out.println(provinciasArray[i]);
    	}    	
    	// Pasar de Array -> Lista
    	List<String> listaDelArray = new ArrayList<String>(Arrays.asList(provinciasArray));
    	
    	List<String> provincias2 = new ArrayList<String>(provincias);
    	List<String> provincias3 = new ArrayList<String>(provincias);
    	List<String> provincias4 = new ArrayList<String>(provincias);
    	List<String> provincias5 = new ArrayList<String>(provincias);
    	List<String> provincias6 = new ArrayList<String>(provincias);
    	List<String> provincias7 = new ArrayList<String>(provincias);
    	List<String> provincias8 = new ArrayList<String>(provincias);
    	
    	Collator primaria = Collator.getInstance(new Locale("es"));
    	Collator secundaria = Collator.getInstance(new Locale("es"));
    	Collator terciaria = Collator.getInstance(new Locale("es"));
    	Collator identical = Collator.getInstance(new Locale("es"));
    	Collator c1 = Collator.getInstance(new Locale("es"));
    	Collator c2 = Collator.getInstance(new Locale("es"));
    	Collator c3= Collator.getInstance(new Locale("es"));
    	
    	primaria.setStrength(Collator.PRIMARY);
    	secundaria.setStrength(Collator.SECONDARY);
    	terciaria.setStrength(Collator.TERTIARY);
    	identical.setStrength(Collator.IDENTICAL);
    	c1.setStrength(Collator.CANONICAL_DECOMPOSITION);
    	c2.setStrength(Collator.FULL_DECOMPOSITION);
    	c3.setStrength(Collator.NO_DECOMPOSITION);
    	
    	provincias2.sort(primaria);
    	provincias3.sort(secundaria);
    	provincias4.sort(terciaria);
    	provincias5.sort(identical);
    	provincias6.sort(c1);
    	provincias7.sort(c2);
    	provincias8.sort(c3);
    	
    	
    	System.out.println("*** Ordenaciones ***");
    	System.out.println("Impresión de las provincias: " + provincias);
    	System.out.println("Impresión del array: " + Arrays.asList(provinciasArray));
    	System.out.println("Collator primary: " + provincias2);
    	System.out.println("Collator secondary: " + provincias3);
    	System.out.println("Collator terciary: " + provincias4);
    	System.out.println("Collator identical: " + provincias5);
    	System.out.println("Collator decomposition: " + provincias6);
    	System.out.println("Collator full: " + provincias7);
    	System.out.println("Collator no-decomposition: " + provincias8);
    	   	
    }
}
