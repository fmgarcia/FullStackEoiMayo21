package com.fran.colecciones;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Hello world!
 *
 */
public class Colecciones 
{
    public static void main( String[] args )
    {
    	//eSet();
    	//eList();
    	//eMap();
    }
    
    public static void eSet() {
    	// Conjunto de elementos no duplicados
    	Set<String> cadenas = new HashSet<String>();    	
    	cadenas.add("primera");
    	cadenas.add("segunda");
    	cadenas.add("tercera");
    	Set<String> cadenas2 = new HashSet<String>(cadenas);  // construir conjunto a partir de otro
    	Set<String> cadenas3 = new HashSet<String>(Arrays.asList("primera","dos","uno"));
    	cadenas.forEach(e->System.out.println(e));
    	System.out.println(cadenas.contains("primera"));
    	cadenas3.forEach(e->System.out.println(e));
    	cadenas.containsAll(cadenas3);  // false
    	cadenas.equals(cadenas3);  // false
    	cadenas.retainAll(cadenas3);  // se queda solo con los elementos que aparezcan en el pasado como parámetro
    	System.out.println("*********");
    	cadenas.forEach(e->System.out.println(e));
    	String[] elementos = (String[])cadenas.toArray();
    	cadenas.removeAll(cadenas3);  // estará vacio
    }
    
    public static void eList() {
    	List<String> cadenas = new ArrayList<String>();    	
    	cadenas.add("primera");
    	cadenas.add("segunda");
    	cadenas.add("tercera");
    	cadenas.add("primera");
    	Set<String> cadenas3 = new HashSet<String>(Arrays.asList("primera","dos","uno"));
    	cadenas.forEach(e->System.out.println(e));
    	System.out.println(cadenas.indexOf("primera")); // 0
    	cadenas.remove(0);
    	System.out.println(cadenas.indexOf("primera")); // 2
    	cadenas.sort(Comparator.naturalOrder());
    	//cadenas.add(null);
    	cadenas.forEach(e->System.out.println(e));
    	cadenas.sort(Comparator.nullsFirst(Comparator.naturalOrder()));
    	cadenas.forEach(e->System.out.println(e));
    	Collections.replaceAll(cadenas, "primera","primeras");
    	cadenas.forEach(e->System.out.println(e));
    	Collections.addAll(cadenas, "otra","otra más");
    	cadenas.addAll(cadenas3);
    	cadenas.forEach(e->System.out.println(e));
    	Collections.sort(cadenas,Collections.reverseOrder()); 
    	System.out.println("**************");
    	cadenas.forEach(e->System.out.println(e));
    	//List<String> cadenasCopia = new ArrayList<String>();    	
    	//Collections.copy(cadenasCopia, cadenas);  // destino, origen
    	//cadenasCopia.forEach(e->System.out.println(e));
    	Collections.sort(cadenas);
    	System.out.println("**************");
    	cadenas.forEach(e->System.out.println(e));
    	System.out.println(Collections.binarySearch(cadenas, "segun"));
    	List<String> disjunta = new ArrayList<String>(Arrays.asList("primera","b","c"));
    	System.out.println(Collections.disjoint(cadenas, disjunta));
    }
    
    public static void eMap() {
    	Map<Integer,String> lenguajes = new HashMap<Integer,String>();
    	lenguajes.put(1, "Java");
    	lenguajes.put(2, "C#");
    	lenguajes.put(3, "C++");
    	lenguajes.put(1, "Python");  // no falla, no inserta pero si reemplaza el valor
    	lenguajes.put(5, "Java");	// Se puede repetir sin problema
    	// Recorrer datos
    	Iterator<Integer> codigo = lenguajes.keySet().iterator();
    	int posicion = 0;
    	while(codigo.hasNext()) {
    		posicion = codigo.next(); // avanzo en el Map
    		System.out.println(posicion + " - " + lenguajes.get(posicion));
    	}
    	System.out.println("*************");
    	lenguajes.replace(1, "Java SE");
    	lenguajes.remove(2);
    	codigo = lenguajes.keySet().iterator();
    	while(codigo.hasNext()) {
    		posicion = codigo.next(); // avanzo en el Map
    		System.out.println(posicion + " - " + lenguajes.get(posicion));
    	}
    	System.out.println("*************");
    	// Recorrer mapa con programación funcional, a partir de Java 8
    	lenguajes.forEach((k,v)->System.out.println("Clave: " + k + " valor: " + v));
    	
    }
    
}
