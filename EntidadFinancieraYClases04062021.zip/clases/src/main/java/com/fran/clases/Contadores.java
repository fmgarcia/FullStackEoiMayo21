package com.fran.clases;

public class Contadores {
	public static int numeroHombres;
	public static int numeroMujeres;
}
