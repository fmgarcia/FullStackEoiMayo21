package com.fran.apirest.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fran.apirest.models.entity.Usuario;

public interface IUsuario extends JpaRepository<Usuario,Integer>{

}
