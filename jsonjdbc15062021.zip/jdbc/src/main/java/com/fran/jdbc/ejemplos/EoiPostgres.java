package com.fran.jdbc.ejemplos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EoiPostgres {
	
	private static final String url = "jdbc:postgresql://localhost:5432/eventos";
	private static final String usuario = "postgres";
	private static final String password = "postgres";
	
	private static Connection con = null;
	private static Statement st = null;
	
	public static void probarConexion() {
		// Utilizamos la interfaz Autocloseable
		try(Connection con = DriverManager.getConnection(url, usuario, password)){
			System.out.println("La conexión se realizó satisfactoriamente");
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public static void probarConexion2() {
		try {
			Class.forName("org.postgresql.Driver");  // Ya no es obligatorio, pero lo podemos encontrar por ahí.
			Connection con = DriverManager.getConnection(url, usuario, password);
			System.out.println("La conexión se realizó satisfactoriamente");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void conexion() {
		try {
			con = DriverManager.getConnection(url, usuario, password);
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void desconexion() {
		try {
			st.close();
			con.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void selectBasica(String sql) {
		ResultSet rs = null;
		try {
			rs = st.executeQuery(sql);
			int registros = 0;
			while(rs.next()) {
				registros++;
				System.out.println(rs.getLong("id") + " " + rs.getString("nombre") + " " + rs.getString("descripcion"));
				/*if(rs.isLast())
					System.out.println("El total de registros es: " + rs.getRow());*/
			}
			System.out.println("El total de registros es: " + registros);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void insertTabla(String sql) {
		try {
			int numerofilas = st.executeUpdate(sql);
			System.out.println("La insert se ejecutó correctamente con " + numerofilas + ((numerofilas==1)?" fila":" filas"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		//probarConexion();
		//probarConexion2();
		conexion();
		//selectBasica("Select * from evento");
		insertTabla("INSERT INTO evento(nombre,descripcion,precio,fecha) VALUES ('fullstack Java2','ejemplo insert',11.50,'27/07/2021'),('fullstack Java3','ejemplo insert',11.50,'27/07/2021');");
		// commit->confirmar una/s operación
		// rollback-> deshacer una/s operción
		desconexion();
		
	}
	
	

}
