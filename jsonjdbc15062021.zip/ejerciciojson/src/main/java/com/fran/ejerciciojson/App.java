package com.fran.ejerciciojson;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.fran.ejerciciojson.entidades.Film;
import com.fran.ejerciciojson.entidades.People;
import com.fran.ejerciciojson.entidades.Starship;
import com.fran.ejerciciojson.utilidades.JsonUtils;
import com.fran.ejerciciojson.utilidades.MenuUtils;
import com.fran.ejerciciojson.utilidades.SerializacionUtils;
import com.fran.ejerciciojson.utilidades.XmlUtils;

/**
 * Hello world!
 *
 */
public class App 
{
	static Scanner sc = new Scanner(System.in);
	final static String RUTA_BASE_PEOPLE = "https://swapi.dev/api/people/";
	final static String RUTA_BASE_FILM = "https://swapi.dev/api/films/";
	final static String CADENA_FINAL = "/?format=json";
	final static String FORMATO = "?format=json";
	static List<People> listaPersonajes = new ArrayList<People>();
	final static String NOMBRE_FICHERO = "listapersonajes.dat";
	final static String NOMBRE_FICHERO_JSON = "cr90.json";
	
	
	public static int tratarMenu() {
		MenuUtils.imprimirMenu("Peliculas Comunes","Serializar Personajes", "DesSerialiar Personajes","Comprobar pasajeros", "Json a XML");
		int opcion = Integer.parseInt(sc.nextLine());
		switch(opcion) {		
		case 1:
			tratarOpcion1();
			break;
		case 2:
			tratarOpcion2();
			break;
			
		case 3:
			tratarOpcion3();
			break;
			
		case 4:
			tratarOpcion4();
			break;
			
		case 5:
			tratarOpcion5();
			
		default:
			break;
		
		}
		return opcion;		
	}
	
	public static void tratarOpcion5() {
		JsonUtils.parseJsonToXml("cr90.json", "cr90convertido.xml");
		/*Starship nave = XmlUtils.XmlToObject("cr90.xml", Starship.class);
		System.out.println(nave);*/
	}
	
	public static void tratarOpcion4() {
		Starship cr90 = JsonUtils.pasarFicheroAObjetoGson(NOMBRE_FICHERO_JSON, Starship.class);
		long passengers = Long.parseLong(cr90.getPassengers());
		System.out.println("Introduzca el nombre de la pelicula:");
		int pelicula = Integer.parseInt(sc.nextLine());
		Film film = JsonUtils.devolverGenericGson(RUTA_BASE_FILM + pelicula + CADENA_FINAL, Film.class);
		List<Starship> naves = new ArrayList<Starship>();
		film.getStarships().forEach(e->naves.add(JsonUtils.devolverGenericGson(
				e.replaceFirst("http", "https").concat(FORMATO),Starship.class)));
		naves.stream()
		.filter(n->!n.getPassengers().equals("n/a"))
		.filter(n->!n.getPassengers().equals("unknown"))
		.peek(n->n.setPassengers(n.getPassengers().replace(",", "")))
		.filter(n->Long.parseLong(n.getPassengers())>passengers)
		.forEach(n->System.out.println(n.getName() + " " + n.getPassengers()));		
	}
	
	public static void tratarOpcion2() {
		SerializacionUtils.serializarListaObjetosGenericos(NOMBRE_FICHERO, listaPersonajes);
		System.out.println("Se han guardado " + listaPersonajes.size() + " elementos");
	}
	
	public static void tratarOpcion3() {
		listaPersonajes = SerializacionUtils.desSerializarListaObjetosGenericos(NOMBRE_FICHERO);
		System.out.println("La lista tiene " + listaPersonajes.size() + " elementos");
		listaPersonajes.forEach(e->System.out.println(e));
	}
	
	public static void tratarOpcion1() {
		System.out.println("Introduzca el primer personaje:");
		int personaje1 = Integer.parseInt(sc.nextLine());
		System.out.println("Introduzca el segundo personaje:");
		int personaje2 = Integer.parseInt(sc.nextLine());
		People persona1 = JsonUtils.devolverGenericGson(RUTA_BASE_PEOPLE + personaje1 + CADENA_FINAL, People.class);
		People persona2 = JsonUtils.devolverGenericGson(RUTA_BASE_PEOPLE + personaje2 + CADENA_FINAL, People.class);
		imprimirPeliculas(peliculasComunes(persona1,persona2));
		guardarPersonajes(persona1,persona2);
	}
	
	public static void guardarPersonajes(People...personajes) {
		for(People p : personajes) {
			if(!listaPersonajes.contains(p))
				listaPersonajes.add(p);
		}
	}
	
	public static List<String> peliculasComunes(People people1, People people2) {
		List<String> urlPeliculas = people1.getFilms();
		urlPeliculas.retainAll(people2.getFilms()); // Cadenas de people1 que aparecen en people2
		urlPeliculas.replaceAll(e->e.replaceFirst("http", "https").concat(FORMATO));
		return urlPeliculas;
	}
	
	public static void imprimirPeliculas(List<String> listaUrl) {
		//listaUrl.forEach(e->System.out.println(e));
		listaUrl.forEach(e->System.out.println(JsonUtils.devolverGenericGson(e, Film.class).getTitle()));
	}
	
    public static void main( String[] args )
    {
    	int opcion = 0;
    	do {
    		opcion = tratarMenu();
    	}while (opcion!=0);
    	
    }
}
