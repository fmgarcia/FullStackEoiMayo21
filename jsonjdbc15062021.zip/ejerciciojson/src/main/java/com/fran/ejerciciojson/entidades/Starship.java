package com.fran.ejerciciojson.entidades;

public class Starship {

	private String name;
	private String model;
	private String manufacturer;
	private String passengers;
	private String cargo_capacity;
	
	public Starship() {
		
	}

	public Starship(String name, String model, String manufacturer, String passengers, String cargo_capacity) {
		super();
		this.name = name;
		this.model = model;
		this.manufacturer = manufacturer;
		this.passengers = passengers;
		this.cargo_capacity = cargo_capacity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getPassengers() {
		return passengers;
	}

	public void setPassengers(String passengers) {
		this.passengers = passengers;
	}

	public String getCargo_capacity() {
		return cargo_capacity;
	}

	public void setCargo_capacity(String cargo_capacity) {
		this.cargo_capacity = cargo_capacity;
	}

	@Override
	public String toString() {
		return "Starship [name=" + name + ", model=" + model + ", manufacturer=" + manufacturer + ", passengers="
				+ passengers + ", cargo_capacity=" + cargo_capacity + "]";
	}
	
	
}


