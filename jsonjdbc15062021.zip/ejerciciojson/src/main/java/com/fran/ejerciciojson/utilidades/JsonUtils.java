package com.fran.ejerciciojson.utilidades;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import com.fran.ejerciciojson.entidades.People;
import com.github.underscore.lodash.U;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

public class JsonUtils {
	
	/**
	 * Recibe una url en formato cadena y devuelve el contenido de esa Url como una cadena
	 * @param web la cadena que almacena la url
	 * @return	Todo el contenido de esa url en un String
	 */
	public static String readUrl(String web) {
		try {
			URL url = new URL(web);
			URLConnection uc = url.openConnection();			
			uc.setRequestProperty("User-Agent", "PostmanRuntime/7.20.1");
			uc.connect();
			String lines = new BufferedReader(
					new InputStreamReader(uc.getInputStream(), 
							StandardCharsets.UTF_8))
					.lines()
					.collect(Collectors.joining());
			//System.out.println(lines);
			return lines;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha podido la leer la URL: " + web);
		}
		return null;
	}
	
	public static String readUrl(String web, String token) {
		try {
			URL url = new URL(web);
			URLConnection uc = url.openConnection();			
			uc.setRequestProperty("User-Agent", "PostmanRuntime/7.20.1");
			uc.setRequestProperty("X-Auth-Token", token);
			uc.connect();
			String lines = new BufferedReader(
					new InputStreamReader(uc.getInputStream(), 
							StandardCharsets.UTF_8))
					.lines()
					.collect(Collectors.joining());
			//System.out.println(lines);
			return lines;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha podido la leer la URL: " + web);
		}
		return null;
	}
	
	public static <T> T pasarFicheroAObjetoGson(String rutaCompleta, Class<T> clase) {
		T resultado = null;
		Reader reader = null;
		try {
			// Creamos objeto de la clase Gson
			Gson gson = new Gson();
			// creamos el reader
			reader = Files.newBufferedReader(Paths.get(rutaCompleta));
			//Convierte Json que lee directamente de fichero a objeto
			resultado = gson.fromJson(reader, clase);
		} catch (JsonSyntaxException e) {
			e.printStackTrace();
		} catch (JsonIOException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
				return resultado;
			} catch (IOException e) {
				return resultado;
			}
		}
		
	}
	
	
	public static <T> T devolverGenericGson(String url, Class<T> clase) {
		String cadena = readUrl(url);
		if (cadena!=null) {
			Gson gson = new Gson();
			T resultado = gson.fromJson(cadena, clase);
			return resultado;
		} else {
			return null;
		}
	}
	
	public static <T> List<T> devolverListaGenericGson(String urlBase,Class<T> clase, int numeroElementos, String cadenaAdicional){
		List<T> resultado = new ArrayList<T>();
		for(int i=1;i<=numeroElementos;i++) {
			T elemento = devolverGenericGson(urlBase+i+cadenaAdicional,clase);
			if(elemento!=null) {
				resultado.add(elemento);
			}
		}
		return resultado;
	}
	
	public static <T> String escribirJsonBonitoGenerico(T objeto) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(objeto);
		return json;
	}
	
	public static void parseJsonToXml(String inputJsonFile, String outputXmlFile) {
		try {
			List<String> lineasJson = Ficheros.devolverLineasFichero8(inputJsonFile);
			List<String> lineasXml = new ArrayList<String>();
			String xml = U.jsonToXml(lineasJson.get(0));
			lineasXml.add(xml);
			Files.write(Paths.get(outputXmlFile), lineasXml);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	
	
}
