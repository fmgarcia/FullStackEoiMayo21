package com.fran.ejerciciojson.utilidades;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class SerializacionUtils {

	
	public static <T> void serializarListaObjetosGenericos(String rutaCompleta,List<T> objetos){
		File fichero = new File(rutaCompleta);
		FileOutputStream ficheroSalida;
		try {
			ficheroSalida = new FileOutputStream(fichero);
			ObjectOutputStream ficheroObjetos = new ObjectOutputStream(ficheroSalida);
			ficheroObjetos.writeObject(objetos);
			ficheroObjetos.close();
			ficheroSalida.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	
	public static <T> ArrayList<T> desSerializarListaObjetosGenericos(String rutaCompleta){
		ArrayList<T> resultado = new ArrayList<T>();
		File fichero = new File(rutaCompleta);
		FileInputStream ficheroEntrada;
		try {
			ficheroEntrada = new FileInputStream(fichero);
			ObjectInputStream ficheroObjetos = new ObjectInputStream(ficheroEntrada);
			resultado = (ArrayList<T>)ficheroObjetos.readObject();
			ficheroObjetos.close();
			ficheroEntrada.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return resultado;
	}
	
}
