package com.fran.eoimvc2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EoiMvc2Application {

	public static void main(String[] args) {
		SpringApplication.run(EoiMvc2Application.class, args);
	}

}
