package com.fran.ejemplo1fran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo1franApplicationTests {

	@Test
	void contextLoads() {
	}

}
