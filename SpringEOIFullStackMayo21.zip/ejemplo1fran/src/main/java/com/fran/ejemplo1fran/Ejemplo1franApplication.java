package com.fran.ejemplo1fran;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo1franApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo1franApplication.class, args);
	}

}
