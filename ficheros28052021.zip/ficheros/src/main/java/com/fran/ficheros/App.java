package com.fran.ficheros;

import java.io.IOException;

import com.fran.ficheros.auxiliares.Ficheros;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException
    {
        //Ficheros.crearFichero("c:/ficheroseoi", "fran.txt");
        //Ficheros.crearFichero("c:/ficheroseoiaaaa/franaaaaa.txt");
        //Ficheros.eliminarFichero("c:/ficheros", "fran.txt");
        //Ficheros.eliminarFichero("c:/ficherosprueba");
    	//Ficheros.renombrarFichero("c:/ficherosprueba", "fran.txt", "eoi.txt");
    	//Ficheros.moverPapelera("c:/ficherosprueba", "eoi.txt");
    	//Ficheros.leerDirectorio("c:/ficheros");
    	//String [] lista = Ficheros.obtenerDatosDirectorio("c:/ficheros");
    	//Ficheros.leerFicheroBufferedReader5("c:/ficheros", "cuentas.txt");
    	Ficheros.leerFichero8("c:/ficheros", "cuentas.txt");
    }
}
