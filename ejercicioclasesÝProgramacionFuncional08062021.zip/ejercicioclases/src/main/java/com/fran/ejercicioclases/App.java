package com.fran.ejercicioclases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

import com.fran.ejercicioclases.utilidades.FicherosUtils;
import com.fran.ejercicioclases.utilidades.MenuUtils;


public class App 
{
	
	public static Scanner sc = new Scanner(System.in);

	public static final String DIRECTORIO = "c:/ficheros/datosbancos";
	public static final String FICHERO_SANTANDER = "santander.txt";
	public static final String FICHERO_SABADELL = "sabadell.txt";
	public static final String FICHERO_CAIXA = "caixa.txt";
	public static List<CuentaSantander> cuentasSantander = new ArrayList<CuentaSantander>();
	public static List<CuentaSabadell> cuentasSabadell = new ArrayList<CuentaSabadell>();
	public static List<CuentaCaixa> cuentasCaixa = new ArrayList<CuentaCaixa>();
	public static List<Cuenta> cuentas = new ArrayList<Cuenta>();
	public static List<Cliente> clientes = new ArrayList<Cliente>();
	

	
	
	public static void crearCuentasBancos() throws IOException {
		List<String> lineasSantander = FicherosUtils.devolverLineasFichero8(DIRECTORIO, FICHERO_SANTANDER);
		lineasSantander.forEach(l->cuentasSantander.add(new CuentaSantander(l)));
		List<String> lineasSabadell = FicherosUtils.devolverLineasFichero8(DIRECTORIO, FICHERO_SABADELL);
		lineasSabadell.forEach(l->cuentasSabadell.add(new CuentaSabadell(l)));
		List<String> lineasCaixa = FicherosUtils.devolverLineasFichero8(DIRECTORIO, FICHERO_CAIXA);
		lineasCaixa.forEach(l->cuentasCaixa.add(new CuentaCaixa(l)));
	}
	
	public static void unirListasCuentas() {
		cuentas.addAll(cuentasSantander);
		cuentas.addAll(cuentasSabadell);
		cuentas.addAll(cuentasCaixa);
		//Cuenta.imprimirListaHijos(cuentas);	
	}
	
	public static void eliminarElementoAleatorio() {
		cuentas.remove(numeroAleatorio(cuentas));
	}
	
	public static <T> int numeroAleatorio(List<T> lista) {
		 return (int)Math.floor(Math.random()*lista.size()); //devuelve un número entre 0 y tamaño de la lista-1
	}
	
	public static void buscarElementoBorrado() {
		if(!cuentas.containsAll(cuentasSantander)) {
			cuentasSantander.forEach(c->{
				if(!cuentas.contains(c)) {
					System.out.println("La cuenta borrada es: " + c);
					//cuentas.add(c);
				}
			});
		} else if(!cuentas.containsAll(cuentasSabadell)) {
			cuentasSabadell.forEach(c->{
				if(!cuentas.contains(c)) {
					System.out.println("La cuenta borrada es: " + c);
				}
			});
		} else if(!cuentas.containsAll(cuentasCaixa)) {
			cuentasCaixa.forEach(c->{
				if(!cuentas.contains(c)) {
					System.out.println("La cuenta borrada es: " + c);
				}
			});
		}
	}
	
	public static void totalesSantander() {
		//System.out.println(cuentasSantander.stream().mapToDouble(c->c.getSaldo()).sum());
		System.out.println(cuentasSantander.stream().mapToDouble(CuentaSantander::getSaldo).sum());
		System.out.println(cuentasSantander.stream().count());
		System.out.println(cuentasSantander.stream().mapToDouble(CuentaSantander::getSaldo).max().orElse(0));	
	}
	
	public static void tratarMenu(List<String> opciones) {
		int opcion = 0;
		do {
			opcion = MenuUtils.devolverOpcionMenu(opciones);
			tratarOpcion(opcion);
		}while(opcion!=0);
	}
	
	public static void tratarOpcion(int opcion) {
		switch(opcion) {
		case 1:
			solucionEjercicio1();
			break;
		case 2:
			//solucionEjercicio2();
			//solucionEjercicio2Christian();
			solucionEjercicio2Cliente();
			break;
		case 3:
			solucionEjercicio3Cliente();
			break;
		case 4:
			solucionEjercicio4Cliente();
			break;
		case 5:
			solucionEjercicio5Cliente();
			break;		
		}
	}
	
	public static void solucionEjercicio1(){
		System.out.println("Introduzca el dni: ");
		String dni = sc.nextLine();
		/*List<Cuenta> cuentaDni = cuentas.stream()
				.filter(e->e.getDni().equals(dni))
				.collect(Collectors.toList());
		double sumaSaldoDni = cuentaDni.stream()
				.mapToDouble(Cuenta::getSaldo)
				.sum();
		System.out.println(cuentaDni.get(0).getNombre() + " " + sumaSaldoDni);*/
		double sumaSaldos = cuentas.stream()
			.filter(e->e.getDni().equals(dni))
			.mapToDouble(Cuenta::getSaldo)
			.sum();
		System.out.println("La suma de los saldos del dni: " + dni + " es " + sumaSaldos);
	}
	
	public static double obtenerSaldoCliente(String dni) {
		return cuentas.stream()
		.filter(e->e.getDni().equals(dni))
		.mapToDouble(Cuenta::getSaldo)
		.sum();
	}
	
	public static String obtenerNombreCliente(String dni) {
		return cuentas.stream()
		.filter(e->e.getDni().equals(dni))
		.map(e->e.getNombre())
		.limit(1)
		.findFirst()
		.orElse(null);
	}
	
	public static void solucionEjercicio2_VersionListadoCuentas(){
		// Sacaría las cuentas con saldos mayores y menores que 0, pero no los totales por cliente
		Map<Boolean,List<Cuenta>> sueldosMorosos =cuentas.stream()
		.collect(Collectors.partitioningBy(e->e.getSaldo()<0.0));
		System.out.println("Clientes con saldo menor que 0");
		sueldosMorosos.get(true).forEach(e->System.out.println(e));
		System.out.println("Clientes con saldo mayor o igual que 0");
		sueldosMorosos.get(false).forEach(e->System.out.println(e));
	}
	
	public static void solucionEjercicio2(){
		Map<String,Double> morosos = new HashMap<String,Double>();
		Map<String,Double> noMorosos = new HashMap<String,Double>();
		Set<String> dnis = cuentas.stream()
			.map(c->c.getDni())
			.collect(Collectors.toSet());
		dnis.forEach(e->{
			if(obtenerSaldoCliente(e)<0) {
				morosos.put(e, obtenerSaldoCliente(e));
			}else {
				noMorosos.put(e, obtenerSaldoCliente(e));
			}
		});
		// Imprimir las listas
		System.out.println("Listado de morosos:");
		morosos.forEach((k,v)->System.out.println("Dni: " + k + " cantidad: " + v));
		System.out.println("Listado de No morosos:");
		noMorosos.forEach((k,v)->System.out.println("Dni: " + k + " cantidad: " + v));
	}
	
	public static void solucionEjercicio2Christian() {
		System.out.println("Listado de morosos:"); 
		cuentas.stream()		 
         .collect(Collectors.groupingBy(Cuenta::getNombre, Collectors.summingDouble(Cuenta::getSaldo)))
         .forEach((k, v) -> {
        	 if(v<0)
        		 System.out.println(k + " " + v);
        });
		System.out.println("Listado de No morosos:");
		cuentas.stream()		 
	        .collect(Collectors.groupingBy(Cuenta::getNombre, Collectors.summingDouble(Cuenta::getSaldo)))
	        .forEach((k, v) -> {
	       	 if(v>=0)
	       		 System.out.println(k + " " + v);
	        });
	}
	
	public static void solucionEjercicio2Cliente(){
		System.out.println("Listado de morosos:"); 
		clientes.stream()
		.filter(c->c.getSaldoTotal()<0)
		.forEach(c->System.out.println(c));
		System.out.println("Listado de No morosos:"); 
		clientes.stream()
		.filter(c->c.getSaldoTotal()>=0)
		.forEach(c->System.out.println(c));
	}
	
	public static void solucionEjercicio3(){
		Cuenta c = cuentas.stream()
			.max(Comparator.comparing(e->obtenerSaldoCliente(e.getDni())))
			.orElse(null);
		System.out.println(c.getDni() + " " + c.getNombre() + " " + obtenerSaldoCliente(c.getDni()));
	}
	
	public static void solucionEjercicio3Cliente(){
		Cliente c = clientes.stream()
			.sorted(Comparator.comparingDouble(Cliente::getSaldoTotal).reversed())
			.findFirst()
			.orElse(null);
		System.out.println(c.getDni() + " " + c.getNombre() + " " + obtenerSaldoCliente(c.getDni()));
	}
	
	public static void solucionEjercicio4(){
		System.out.println("Introduzca cadena a buscar: ");
		String cadena = sc.nextLine();
		Set<Cuenta> clientes = cuentas.stream()
			.filter(e->e.getNombre().toLowerCase().contains(cadena.toLowerCase()))
			.collect(Collectors.toSet());
		clientes.forEach(e->System.out.println(e.getNombre() + " " + obtenerSaldoCliente(e.getDni())));
	}
	
	public static void solucionEjercicio4Cliente(){
		System.out.println("Introduzca cadena a buscar: ");
		String cadena = sc.nextLine();
		clientes.stream()
		.filter(e->e.getNombre().toLowerCase().contains(cadena.toLowerCase()))
		.forEach(e->System.out.println(e.getNombre() + " " + e.getSaldoTotal()));
	}
	
	public static void solucionEjercicio5Cliente(){
		System.out.println("Introduzca cliente a buscar: ");
		int numero = Integer.parseInt(sc.nextLine());
		clientes.stream()
			.sorted(Comparator.comparingDouble(Cliente::getSaldoTotal).reversed())
			.skip(numero-1)
			.limit(1)
			.forEach(e->System.out.println(e.getNombre() + " " + e.getSaldoTotal()));
	}
	
	public static void cargarTotales() {
		Set<String> dnis = cuentas.stream()
				.map(c->c.getDni())
				.collect(Collectors.toSet());
		dnis.forEach(d->clientes.add(new Cliente(d,obtenerNombreCliente(d),obtenerSaldoCliente(d))));		
	}
	
    public static void main( String[] args ) throws IOException
    {
    	crearCuentasBancos();
    	unirListasCuentas();
    	/*eliminarElementoAleatorio();
    	buscarElementoBorrado();
    	totalesSantander();*/
    	cargarTotales();
    	tratarMenu(List.of("Obtener saldo Cliente","Obtener Morosos y no morosos","Cliente Preferido","Cliente por nombre","Cliente concreto"));
    	
    }
}
