package com.fran.ejercicioclases;

public class Cliente {
	
	private String dni;
	private String nombre;
	private double saldoTotal;
	
	public Cliente() {
		
	}

	public Cliente(String dni, String nombre, double saldoTotal) {
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.saldoTotal = saldoTotal;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getSaldoTotal() {
		return saldoTotal;
	}

	public void setSaldoTotal(double saldoTotal) {
		this.saldoTotal = saldoTotal;
	}

	@Override
	public String toString() {
		return "Cliente [dni=" + dni + ", nombre=" + nombre + ", saldoTotal=" + saldoTotal + "]";
	}
	
	

}
