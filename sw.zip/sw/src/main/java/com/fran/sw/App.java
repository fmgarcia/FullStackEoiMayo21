package com.fran.sw;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.fran.sw.entidades.People;

/**
 * Hello world!
 *
 */
public class App 
{
	
	static SessionFactory sessionFactory = null;
	static Session session = null;
	
	// Abre la sesión
	public static void tearUp() {
		sessionFactory = new Configuration().configure().buildSessionFactory();
		session = sessionFactory.openSession();
	}
	
	// Cierra la sesión
	public static void tearDown() {
		session.close();
	}
	
	public static void probarConexionBBDD() {
		if(session!=null) {
			System.out.println("Sesión abierta");
		} else {
			System.out.println("Fallo en la sesión");
		}
	}
	
	public static void mostrarPeople() {
		List<People> resultados = session.createQuery("from People where codigo=1").list();
		System.out.println("Imprimiendo el personaje:");
		if (resultados.size()>0) {
			People p = resultados.get(0);
			System.out.println("Nombre:" + p.getName());
			System.out.println("Ha participado en: ");
			p.getFilmses().forEach(f->System.out.println(f.getTitle()));
			System.out.println("Ha conducido las naves: ");
			p.getStarshipses().forEach(n->System.out.println(n.getName()));
		}		
	}
	
    public static void main( String[] args )
    {
    	@SuppressWarnings("unused")
    	org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
    	java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);
    	
    	tearUp();
    	//probarConexionBBDD();
    	mostrarPeople();
    	tearDown();
    }
}
