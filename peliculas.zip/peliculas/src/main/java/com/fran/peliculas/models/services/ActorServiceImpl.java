package com.fran.peliculas.models.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fran.peliculas.models.dao.IActorDao;
import com.fran.peliculas.models.entity.Actor;

@Service
public class ActorServiceImpl implements IActorService {
	
	@Autowired
	private IActorDao actorDao;

	@Override
	@Transactional(readOnly=true)
	public List<Actor> findAll() {
		return (List<Actor>)actorDao.findAll();
	}

	@Override
	@Transactional(readOnly=true)
	public Actor findById(Long id) {
		return actorDao.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public Actor save(Actor actor) {
		return actorDao.save(actor);
	}

	@Override
	@Transactional
	public void delete(Long id) {
		actorDao.deleteById(id);		
	}

}
