package com.fran.peliculas.models.services;

import java.util.List;

import com.fran.peliculas.models.entity.Pelicula;

public interface IPeliculaService {
	
	public List<Pelicula> findAll();	// buscar todos los clientes
	
	public Pelicula findById(Long id);	// buscar un cliente por Id
	
	public Pelicula save(Pelicula pelicula);	// Inserta un cliente en la base de datos
	
	public void delete(Long id); // Borrara un cliente de la base de datos

}
