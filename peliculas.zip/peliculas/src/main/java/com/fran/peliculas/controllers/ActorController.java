package com.fran.peliculas.controllers;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fran.peliculas.models.entity.Actor;
import com.fran.peliculas.models.services.IActorService;

@CrossOrigin(origins= {"http://localhost:4200"})
@RestController
@RequestMapping("/api/actor")
public class ActorController {
	
	@Autowired
	IActorService claseService;
	
	@GetMapping("")
	public ResponseEntity<?> index(){
		List<Actor> listaResultados = null;
		Map<String,Object> response = new HashMap<>();
		try {
			listaResultados = claseService.findAll();
		} catch (DataAccessException e) {	// Falla al acceder a la base de datos
			response.put("mensaje", "Error al acceder a la base de datos");
			response.put("error", e.getMessage().concat(": ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}		
		/*if(listaClientes==null) {
			response.put("mensaje", "La lista está vacia");
			response.put("clientes", listaClientes);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);	
		}*/
		// Ha podido acceder a la base de datos y el objeto existe	
		return new ResponseEntity<List<Actor>>(listaResultados,HttpStatus.OK);		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> index(@PathVariable Long id){
		Actor objeto = null;
		Map<String,Object> response = new HashMap<>();
		try {
			objeto = claseService.findById(id);  // Acceso a la base de datos
		} catch (DataAccessException e) {	// Falla al acceder a la base de datos
			response.put("mensaje", "Error al acceder a la base de datos");
			response.put("error", e.getMessage().concat(": ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		// Accede a la base datos pero el id no existe
		if(objeto==null) {
			response.put("mensaje", "El objeto con ID: ".concat(id.toString()).concat(" no existe en la base de datos"));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.NOT_FOUND);
		}
		// Ha podido acceder a la base de datos y el objeto existe	
		return new ResponseEntity<Actor>(objeto,HttpStatus.OK);
	}
	
	
	
	@PostMapping("")
	public ResponseEntity<?> create(@Valid @RequestBody Actor objeto, BindingResult result) {		
		Actor objetoNew = null;
		Map<String,Object> response = new HashMap<>();
		
		if(result.hasErrors()) {
			List<String> errores = result.getFieldErrors()
					.stream()
					.map(error->"El campo '" + error.getField() + "' " + error.getDefaultMessage())
					.collect(Collectors.toList());
			response.put("errores", errores);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.BAD_REQUEST);
		}
		
		try {
			objetoNew = claseService.save(objeto);
		} catch (DataAccessException e) {
			response.put("mensaje", "Error al acceder a la base de datos");
			response.put("error", e.getMessage().concat(": ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}		
		response.put("mensaje", "El objeto ha sido insertado con exito");
		response.put("objeto", objetoNew);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<?> update(@Valid @RequestBody Actor objeto, BindingResult result, @PathVariable Long id) {
		
		Actor objetoUpdated = null;
		Map<String,Object> response = new HashMap<>();
		
		if(result.hasErrors()) {
			List<String> errores = result.getFieldErrors()
					.stream()
					.map(error->"El campo '" + error.getField() + "' " + error.getDefaultMessage())
					.collect(Collectors.toList());
			response.put("errores", errores);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.BAD_REQUEST);
		}
		
		Actor objetoParaModificar = null;
		try {
			objetoParaModificar = claseService.findById(id);
		} catch (DataAccessException e1) {
			response.put("mensaje", "Error al acceder a la base de datos");
			response.put("error", e1.getMessage().concat(": ").concat(e1.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		if(objetoParaModificar==null) {  // No existe
			response.put("mensaje", "El objeto con ID: ".concat(id.toString()).concat(" no existe en la base de datos"));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.NOT_FOUND);
		}				
		try {
			if(objeto.getNombre()!=null)
				objetoParaModificar.setNombre(objeto.getNombre());	// cambio los campos
			if(objeto.getApellido()!=null)
				objetoParaModificar.setApellido(objeto.getApellido());
			if(objeto.getFechanac()!=null)
				objetoParaModificar.setFechanac(objeto.getFechanac());
			if(objeto.getPais()!=null)
				objetoParaModificar.setPais(objeto.getPais());
			if(objeto.getPeliculas().size()==0)
			objetoParaModificar.setPeliculas(objeto.getPeliculas());
			objetoUpdated = claseService.save(objetoParaModificar);	// guardos los cambios
		} catch (DataAccessException e) {	// No lo puedo guardar
			response.put("mensaje", "Error al acceder a la base de datos");
			response.put("error", e.getMessage().concat(": ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		// Ha podido modificar el objeto		
		response.put("mensaje", "El objeto ha sido modificado con exito");
		response.put("cliente", objetoUpdated);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.CREATED);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable Long id) {
		
		Map<String,Object> response = new HashMap<>();	
		try {
			claseService.delete(id);
		} catch (DataAccessException e) {	// No lo puedo borrar
			response.put("mensaje", "Error al acceder a la base de datos");
			response.put("error", e.getMessage().concat(": ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		// Ha podido borrar el objeto		
		response.put("mensaje", "El objeto ha sido borrado con exito");
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);	
	}
	
}
