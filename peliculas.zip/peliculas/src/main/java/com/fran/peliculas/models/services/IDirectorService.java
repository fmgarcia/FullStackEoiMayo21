package com.fran.peliculas.models.services;

import java.util.List;

import com.fran.peliculas.models.entity.Director;

public interface IDirectorService {
	
	public List<Director> findAll();	// buscar todos los clientes
	
	public Director findById(Long id);	// buscar un cliente por Id
	
	public Director save(Director director);	// Inserta un cliente en la base de datos
	
	public void delete(Long id); // Borrara un cliente de la base de datos

}
