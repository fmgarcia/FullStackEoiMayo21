package com.fran.peliculas.models.services;

import java.util.List;

import com.fran.peliculas.models.entity.Actor;

public interface IActorService {
	
	public List<Actor> findAll();	// buscar todos los actores
	
	public Actor findById(Long id);	// buscar un actor por Id
	
	public Actor save(Actor actor);	// Inserta un actores en la base de datos
	
	public void delete(Long id); // Borrara un actor de la base de datos

}
