package com.fran.peliculas.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.fran.peliculas.models.entity.Actor;

public interface IActorDao extends CrudRepository<Actor,Long> {

}
