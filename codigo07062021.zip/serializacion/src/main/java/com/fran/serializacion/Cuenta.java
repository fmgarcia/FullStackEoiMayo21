package com.fran.serializacion;

import java.io.Serializable;

public class Cuenta implements Serializable {

	private static final long serialVersionUID = 2L;
	String nombre;
	String apellido;
	String numero;
	
	public Cuenta() {
		
	}

	public Cuenta(String nombre, String numero) {
		super();
		this.nombre = nombre;
		this.numero = numero;
	}
	
	

	public Cuenta(String nombre, String apellido, String numero) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.numero = numero;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	
	
	
	
}
