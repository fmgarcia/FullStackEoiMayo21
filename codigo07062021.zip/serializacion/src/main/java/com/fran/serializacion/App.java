package com.fran.serializacion;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fran.serializacion.utilidades.SerializacionUtils;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //SerializacionUtils.serializarObjeto("personas.dat");  // guarda los objetos en ficheros para no perderlos al salir del programa
        //SerializacionUtils.desSerializarObjeto("personas.dat");  // recupera los objetos de un fichero, normalmente se usa al comienzo del programa para coger datos de una ejecución anterior
    	/*List<Persona> personas = new ArrayList<Persona>();
    	personas.add(new Persona("Fran", "222", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345));
    	personas.add(new Persona("Fran", "111", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345));
    	personas.add(new Persona("Fran", "333", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345));
    	personas.add(new Persona("Fran", "444", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345));
    	personas.add(new Persona("Fran", "555", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345));
    	personas.add(new Persona("Fran", "666", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345));
    	personas.add(new Persona("Fran", "777", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345));
    	personas.add(new Persona("Fran", "888", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345));
    	personas.add(new Persona("Fran", "999", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345));
    	SerializacionUtils.serializarListaObjetosGenericos("personas.dat", personas);*/
    	/*List<Persona> personas = SerializacionUtils.desSerializarListaObjetosGenericos("personas.dat");
    	personas.forEach(p->System.out.println(p));*/
    	
    	/*List<Cuenta> cuentas = new ArrayList<Cuenta>();
    	cuentas.add(new Cuenta("Fran","111"));
    	cuentas.add(new Cuenta("Fran2","222"));
    	SerializacionUtils.serializarListaObjetosGenericos("cuentas.dat", cuentas);*/
    	List<Cuenta> cuentas2 = SerializacionUtils.desSerializarListaObjetosGenericos("cuentas.dat");
    	cuentas2.forEach(c->System.out.println(c));
    }
}
