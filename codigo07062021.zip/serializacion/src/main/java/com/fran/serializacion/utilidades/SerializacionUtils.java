package com.fran.serializacion.utilidades;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fran.serializacion.Persona;

public class SerializacionUtils {

	public static void serializarObjeto(String rutaCompleta){
		File fichero = new File(rutaCompleta);
		FileOutputStream ficheroSalida;
		try {
			ficheroSalida = new FileOutputStream(fichero);
			ObjectOutputStream ficheroObjetos = new ObjectOutputStream(ficheroSalida);
			Persona p = new Persona("Fran", "222", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345);
			ficheroObjetos.writeObject(p);
			Persona p2 = new Persona("Francisco", "111", LocalDate.of(1976, 7, 27), 'H', "Mi casa", 'S', 1000.0, 12345);
			ficheroObjetos.writeObject(p2);
			ficheroObjetos.close();
			ficheroSalida.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	public static void desSerializarObjeto(String rutaCompleta){
		File fichero = new File(rutaCompleta);
		FileInputStream ficheroEntrada;
		try {
			ficheroEntrada = new FileInputStream(fichero);
			ObjectInputStream ficheroObjetos = new ObjectInputStream(ficheroEntrada);
			Persona p = (Persona)ficheroObjetos.readObject();
			System.out.println(p);
			Persona p2 = (Persona)ficheroObjetos.readObject();
			System.out.println(p2);
			ficheroObjetos.close();
			ficheroEntrada.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}
	
	public static void serializarListaObjetos(String rutaCompleta,List<Persona> personas){
		File fichero = new File(rutaCompleta);
		FileOutputStream ficheroSalida;
		try {
			ficheroSalida = new FileOutputStream(fichero);
			ObjectOutputStream ficheroObjetos = new ObjectOutputStream(ficheroSalida);
			ficheroObjetos.writeObject(personas);
			ficheroObjetos.close();
			ficheroSalida.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	
	public static ArrayList<Persona> desSerializarListaObjetos(String rutaCompleta){
		ArrayList<Persona> resultado = new ArrayList<Persona>();
		File fichero = new File(rutaCompleta);
		FileInputStream ficheroEntrada;
		try {
			ficheroEntrada = new FileInputStream(fichero);
			ObjectInputStream ficheroObjetos = new ObjectInputStream(ficheroEntrada);
			resultado = (ArrayList<Persona>)ficheroObjetos.readObject();
			ficheroObjetos.close();
			ficheroEntrada.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return resultado;
	}
	
	public static <T> void serializarListaObjetosGenericos(String rutaCompleta,List<T> objetos){
		File fichero = new File(rutaCompleta);
		FileOutputStream ficheroSalida;
		try {
			ficheroSalida = new FileOutputStream(fichero);
			ObjectOutputStream ficheroObjetos = new ObjectOutputStream(ficheroSalida);
			ficheroObjetos.writeObject(objetos);
			ficheroObjetos.close();
			ficheroSalida.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	
	public static <T> ArrayList<T> desSerializarListaObjetosGenericos(String rutaCompleta){
		ArrayList<T> resultado = new ArrayList<T>();
		File fichero = new File(rutaCompleta);
		FileInputStream ficheroEntrada;
		try {
			ficheroEntrada = new FileInputStream(fichero);
			ObjectInputStream ficheroObjetos = new ObjectInputStream(ficheroEntrada);
			resultado = (ArrayList<T>)ficheroObjetos.readObject();
			ficheroObjetos.close();
			ficheroEntrada.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return resultado;
	}
	
}
