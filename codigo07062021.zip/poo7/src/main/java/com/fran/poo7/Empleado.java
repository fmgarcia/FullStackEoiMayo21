package com.fran.poo7;

public class Empleado implements IEmpleado{

	private String nif;
	private String nombre;
	private double sueldobase;
	private int irpf;
	private int numhorasextras;
	private boolean casado;
	private int hijos;
	private static double horaextra;
	
	
	// Constructores
	public Empleado() {

	}


	public Empleado(String nif) {
		this.nif = nif;
	}


	// Getters and Setters
	
	public String getNif() {
		return nif;
	}


	public void setNif(String nif) {
		this.nif = nif;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public double getSueldobase() {
		return sueldobase;
	}


	public void setSueldobase(double sueldobase) {
		this.sueldobase = sueldobase;
	}


	public int getIrpf() {
		return irpf;
	}


	public void setIrpf(int irpf) {
		this.irpf = irpf;
	}


	public int getNumhorasextras() {
		return numhorasextras;
	}


	public void setNumhorasextras(int numhorasextras) {
		this.numhorasextras = numhorasextras;
	}


	public boolean isCasado() {
		return casado;
	}


	public void setCasado(boolean casado) {
		this.casado = casado;
	}


	public int getHijos() {
		return hijos;
	}


	public void setHijos(int hijos) {
		this.hijos = hijos;
	}


	public static double getHoraextra() {
		return horaextra;
	}


	public static void setHoraextra(double horaextra) {
		Empleado.horaextra = horaextra;
	}

	@Override
	public double calculoComplemento() {
		return this.numhorasextras*this.horaextra;
	}


	@Override
	public double sueldoBruto() {
		return this.sueldobase + this.calculoComplemento();
	}


	@Override
	public double retencion() {
		int irpffinal=this.irpf;
		if(this.casado) {
			irpffinal -= 2;
		}
		if(this.hijos>0) {
			irpffinal -= this.hijos;
		}
		if(irpffinal<0) {
			irpffinal = 0;
		}
		return (this.sueldoBruto()*(irpffinal/100));		
	}


	@Override
	public String toString() {
		
		String cadena = "";
		cadena += nif + " " + nombre + "\n";
		cadena += "Sueldo base: " + sueldobase + "\n";
		cadena += "Horas extras: " + numhorasextras + "\n";
		cadena += "Tipo IRPF: " + this.irpf + "\n";
		cadena += "Casado: " + (this.casado?"S":"N") + "\n";
		cadena += "Número de hijos: " + this.hijos + "\n";
		
		return cadena;
		
	}
	
	
	
	
	

	
	
	
	
	
}
