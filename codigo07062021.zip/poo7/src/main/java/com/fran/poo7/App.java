package com.fran.poo7;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class App 
{
	static Scanner sc = new Scanner(System.in);
	
    public static void main( String[] args )
    {
        System.out.println("Introduce el número de empleados:");
        int numempleados = Integer.parseInt(sc.nextLine());
        if(numempleados>20) {
        	numempleados=20;
        }
        Empleado[] empleados = new Empleado[numempleados];
        for(int i=0; i<numempleados; i++) {
        	empleados[i] = new Empleado();
        	System.out.println("Introduzca Nif: ");
        	empleados[i].setNif(sc.nextLine());
        	System.out.println("Introduzca Nombre:");
        	empleados[i].setNombre(sc.nextLine());
        	System.out.println("Introduzca Sueldo base:");
        	empleados[i].setSueldobase(sc.nextDouble());
        	System.out.println("Introduzca Horas extras:");
        	empleados[i].setNumhorasextras(sc.nextInt());
        	System.out.println("Introduzca IRPF:");
        	empleados[i].setIrpf(sc.nextInt());
        	System.out.println("Introduzca si está casado (s/n):");
        	empleados[i].setCasado(sc.next().toLowerCase().charAt(0)=='s'?true:false);
        	System.out.println("Introduzca número de hijos:");
        	empleados[i].setHijos(sc.nextInt());
        	sc.nextLine();
        }
        // El atributo de clase solo se pide una vez
        System.out.println("Introduzca el precio de la hora extra:");
    	Empleado.setHoraextra(sc.nextDouble());
    	
    	// **********Trabajando con arrays****************
    	Arrays.sort(empleados, (e1,e2)->Double.compare(e1.sueldoBruto()-e1.retencion(), e2.sueldoBruto()-e2.retencion()));
        // el que más gana es el último elemento del array
    	System.out.println(empleados[numempleados-1].toString());
    	// el que menos gana es el primer elemento del array
    	System.out.println(empleados[0].toString());
    	
    	Arrays.sort(empleados, (e1,e2)->Double.compare(e1.calculoComplemento(), e2.calculoComplemento()));
        // el que más gana es el último elemento del array
    	System.out.println(empleados[numempleados-1].toString());
    	// el que menos gana es el primer elemento del array
    	System.out.println(empleados[0].toString());
    	
    	Arrays.sort(empleados, (e1,e2)->Double.compare(e1.sueldoBruto(), e2.sueldoBruto()));
    	for(Empleado e : empleados) {
    		System.out.println(e.toString());
    	}
    	// **********Trabajando con arrays****************
    	
    	// ********Transformar array en lista**************
    	List<Empleado> listaEmpleados = Arrays.asList(empleados);
    	listaEmpleados.stream()
    		.sorted((e1,e2)->Double.compare(e1.sueldoBruto()-e1.retencion(), e2.sueldoBruto()-e2.retencion()))
    		.forEach(e->System.out.println(e));
  
    }
}
