package com.fran.poo7;

public interface IEmpleado {

	public double calculoComplemento();
	public double sueldoBruto();
	public double retencion();
}
