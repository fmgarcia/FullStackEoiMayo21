package com.fran.holamundomaven;

/**
 * Hello world!
 *
 */
public class Prueba {
	public static void main(String[] args) {
		System.out.println();
		for (String string : args) {

		}
	}

}
