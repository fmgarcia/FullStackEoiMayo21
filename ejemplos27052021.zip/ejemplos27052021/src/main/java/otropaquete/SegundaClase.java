package otropaquete;

import com.fran.ejemplos27052021.App;

public class SegundaClase {

	private String ejemploVisibilidad = "hola";
	public static String otravariable = "Fran";

}
