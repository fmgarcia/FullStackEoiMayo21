package com.fran.ejemplos27052021;

public class FechasFran {
	
	static String cadena = "hola";

	public static String devuelveHola() {
		return cadena;
	}

	public static void metodo2() {

	}

	public static void metodo3() {

	}

}
