package com.fran.ejemplos27052021;

public class TerceraClase {

	static String otraVariable = "adiós";
	
}
