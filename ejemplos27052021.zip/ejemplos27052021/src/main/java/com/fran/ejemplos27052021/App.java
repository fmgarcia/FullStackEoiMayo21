package com.fran.ejemplos27052021;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import otropaquete.SegundaClase;

/**
 * Hello world!
 *
 */
public class App {
	// visibilidades: public, protected, private, no especificado
	// Static vs non-static
	protected static String cadena = "hola";
	static final double PI = 3.14;

	public static void main(String[] args) {
		// otroMetodo();
		/* FechasFran.devuelveHola();
		// ejemploScanner();
		// ejemploTernarias();
		// ejemploWrapper(); */
		// ejemploConversiones();
		//comparacionesIntegerString();
		// ejemplosString();
		// ejemplosInmutabilidad();
		// llamarParametros();
		ejemploValoresMaximosMinimos();

	}

	public static void otroMetodo() {
		SegundaClase sc = new SegundaClase();
		TerceraClase tc = new TerceraClase();
		// System.out.println(sc.ejemploVisibilidad);
		System.out.println(TerceraClase.otraVariable);
		// FechasFran.metodo1();
		// PI = PI + 1;
		String cadena2 = SegundaClase.otravariable;
	}

	public static void ejemploScanner() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca texto");
		String texto = sc.nextLine();
		System.out.println(texto);
		System.out.println("Introduzca número");
		int numero = sc.nextInt();
		System.out.println(numero);
	}

	public static int ejemploTernarias() {
		int a = 11;
		if (a < 10) {
			System.out.println("Número menor que 10");
		} else {
			System.out.println("Número mayor o igual a 10");
		}

		System.out.println(a < 10 ? "Número menor que 10" : "Número mayor o igual a 10");
		int b = (a < 10 || a > 20) ? 4 : 5;
		System.out.println(b);
		return (a < 10) ? 4 : 5;
	}
	
	// Clases envolventes
	public static void ejemploWrapper() {
		
		int a = 10;  // tipo primitivo
		Integer a2 = 10; // clase envolvente de int
		Integer a3 = 15;
		String cadena = a2.toString();
		char c = a2.toString().charAt(0);
		System.out.println(c);
		int a4 = a2 + a3; // unboxing
		Integer a5 = a;  // boxing
		Long numeroLargo = 10L;
		Character caracter;
		
	}

	public static void ejemploConversiones() {
		int numero = 27;
		Integer numero2 = new Integer(numero);
		int otroNumero = Integer.parseInt("40");  // String -> int
		String cadena = String.valueOf(20);   // int -> String
		String otracadena = Integer.toString(20); // int -> String
		String cadenaconcatenada = numero + ""; // int -> String
	}
	
	public static void comparacionesIntegerString() {
		Integer a = 1;
		Integer a1 = 1;
		Integer b = 201;
		Integer b1 = 201;
		String cadena = "hola";
		String cadena2 = "hola";
		System.out.println(a==a1);
		System.out.println(b==b1);
		System.out.println(a.compareTo(a1));
		System.out.println(b.compareTo(b1));
		if(cadena==cadena2) {  // Mal para comparar
			
		}
		if(cadena.equals(cadena2)) { // correcto
			
		}
	}
	
	/**
	 * Método donde veremos ejemplos de String
	 */
	public static void ejemplosString() {
		String cadena = "hola Mundo";
		System.out.println("Introduce cadena a buscar: ");
		Scanner sc = new Scanner(System.in);
		String cadenaIntroducida = "";
		int numero = 20;
		
		System.out.println("Longitud: " + cadena.length());  // 10
		System.out.println(cadena.indexOf('a'));  // 3
		System.out.println(cadena.indexOf("Mu"));  // 5
		System.out.println(cadena.toLowerCase().indexOf(cadenaIntroducida.toLowerCase()));  // 5
		System.out.println(cadena.substring(2,4)); // la
		System.out.println(cadena.equals("hola Mundo")); // true
		System.out.println(cadena.compareTo("z")); // -18
		System.out.println(cadena.valueOf("10"));  // 10
		System.out.println("hola " + numero+5 ); // hola 205

		
	}
	
	// Ejemplos de sobrecarga de métodos
	public static void ejemplosString(String param1) {
		
	}
	
	public static void ejemplosString(int param1) {
		ejemplosString(Integer.toString(param1));
	}
	
	public static void ejemplosInmutabilidad() {
		String cadena = "hola";
		StringBuffer cadenaBuffer = new StringBuffer("hola");  // trabajar en entornos multihilos
		StringBuilder cadenaBuilder = new StringBuilder(cadena);  // no trabaja con hilos
		System.out.println(cadena);
		cadena = cadena + " mundo";
		System.out.println(cadena);  // hola mundo
		ejemplosConcatenar(cadena);
		System.out.println(cadena); // hola mundo
		ejemplosConcatenar(cadenaBuilder);
		System.out.println(cadenaBuilder.reverse());  // narF aloh
	}
	
	// NO permanecen los cambios que se hagan en el parámetro
	public static void ejemplosConcatenar(String param) {
		param = param + " Fran";
	}
	
	// Si permanecen los cambios que se hagan en el parámetro
	public static void ejemplosConcatenar(StringBuilder param) {
		param.append(" Fran");
	}
	
	public static void llamarParametros() {
		int param1 = 10;
		int param2 = 20;
		Integer param3 = 30;
		Integer param4 = 40;
		ejemploParametros(param1,param2,param3, param4);
		System.out.println(param1); // 10
		System.out.println(param2); // 20
		System.out.println(param3); // 30
		System.out.println(param4); // 40
		
		// Solución listas
		List<Integer> listaNumeros = new ArrayList<Integer>();
		listaNumeros.add(param1);
		listaNumeros.add(param2);
		listaNumeros.add(param3);
		listaNumeros.add(param4);
		
		int[] numeros = {param1,param2,param3,param4};  // Esto también permite modificar
		
		ejemploParametros(listaNumeros);
		
		for(Integer numero : listaNumeros) { // imprime una lista
			System.out.println(numero);
		}
	}
	
	public static void ejemploParametros(int a, int b, Integer c, Integer d) {
		a = a +1;
		b = b + 1;
		c = new Integer(50);
		d = new Integer(60);
	}
	
	public static void ejemploParametros(List<Integer> listaNumeros) {
		for(int i=0;i<listaNumeros.size();i++) {
			listaNumeros.set(i, listaNumeros.get(i) + 1);
		}
	}
	
	
	public static void ejemploValoresMaximosMinimos() {
		int a = 2147483647;
		System.out.println(a+1); // -2147483648 = Integer.MIN_VALUE
		int maximo = Integer.MAX_VALUE; // 2147483647
		
		int num1 = 2147483600;
		int num2 = 1000;
		long num3 = 0;
		if (((long)num1+(long)num2)>Integer.MAX_VALUE) {
			System.out.println("Te pasas del máximo");
		}
		else {
			System.out.println(num1+num2);
		}
	}
	
	public static void castear() {
		//String cadena = (String)'a';
		double numero = (double)10.50f;
		//int numero2 = (int)"10";
	}
	
	
	
}
