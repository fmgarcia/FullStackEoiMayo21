package com.fran.fechas;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Set;

public class Fechas {

	public static void main(String[] args) {
		//eDate5();
		//eLocalDate8();
		//eLocalTime8();
		//eLocalDateTime8();
		//ePeriod8();
		//eDuration8();
		//eZoneId();
		//eTemporalAdjusters8();
		//eParse8();
	}
	
	public static void eDate5() {
		// Java 5
		Date fecha = new Date();
		System.out.println(fecha);
		Date fecha2 = new Date(121,5,2);  // 02/06/2021
		System.out.println(fecha2);
		Date fecha3 = new Date("27/07/1976");
		System.out.println(fecha3);
		Date fecha4 = new Date("07/27/1976");
		System.out.println(fecha4);	
		try {
			Date fecha5 = new SimpleDateFormat("dd/MM/yyyy").parse("27/07/1976");
			System.out.println(fecha5);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	public static void eLocalDate8() {
		LocalDate localDate = LocalDate.now();
		System.out.println(localDate);
		LocalDate localDateOf = LocalDate.of(2021, 6, 2);
		System.out.println(localDateOf);
		LocalDate suma30 = localDate.plusDays(30);
		System.out.println(suma30);
		LocalDate finPlazo = LocalDate.of(2021,6,3);
		if(LocalDate.now().isAfter(finPlazo)) {
			System.out.println("Te has pasado de plazo");
		} else {
			System.out.println("Estás en plazo");
		}
		System.out.println(LocalDate.now().isAfter(finPlazo)?"Te has pasado de plazo":"Estás en plazo");		
	}
	
	public static void eLocalTime8() {
		LocalTime localTime = LocalTime.now();  // hora actual
		System.out.println(localTime);
		LocalTime localTimeOf = LocalTime.of(9, 25);  // 9:25
		LocalTime suma3horas = LocalTime.now().plusHours(3);
		LocalTime suma20horas = LocalTime.now().plus(20, ChronoUnit.HOURS);
	}
	
	public static void eLocalDateTime8() {
		LocalDateTime localDateTime = LocalDateTime.now();  // coge los valores actual de fecha y hora
		LocalDateTime localDateTimeOf = LocalDateTime.of(2021, Month.JUNE, 2, 10, 3);
	}
	
	public static void ePeriod8() {
		// Diferencias de fechas
		LocalDate fechaNacimiento = LocalDate.of(1976,7,27);
		LocalDate hoy = LocalDate.now();
		int anyos = Period.between(fechaNacimiento, hoy).getYears();
		int meses = Period.between(fechaNacimiento, hoy).getMonths();
		int dias = Period.between(fechaNacimiento, hoy).getDays();
		System.out.println("Tengo " + anyos + " años, " + meses + " meses, y " + dias + " días");
	}
	
	public static void eDuration8() {
		// Diferencias en tiempo
		LocalTime horaActual = LocalTime.now();
		LocalTime finClase = LocalTime.of(14, 0);
		System.out.println("Todavía queda : " + Duration.between(horaActual, finClase).toMinutes() + " minutos");
	}
	
	public static void eZoneId() {
		// Listado de las diferentes zonas horarias
		/*Set<String> zonasHorarias = ZoneId.getAvailableZoneIds();
		zonasHorarias.stream().sorted().forEach(e->System.out.println(e));*/
		// Los datos de Tokyo
		System.out.println("La hora de Tokyo es: ");
		System.out.println(LocalDateTime.now(ZoneId.of("Asia/Tokyo")));
	}
	
	public static void eTemporalAdjusters8() {
		System.out.println("El último día de este mes es: ");
		System.out.println(LocalDate.now().with(TemporalAdjusters.lastDayOfMonth()));
	}
	
	public static void eParse8() {
		LocalDate hoy = LocalDate.parse("2021-06-02");  // ISO yyyy/mm/dd
		System.out.println(hoy);
		LocalDateTime ahora = LocalDateTime.parse("2021-06-02T10:22:45");
		System.out.println(ahora);
		LocalDate hoyEspanya = LocalDate.parse("2/6/2021",DateTimeFormatter.ofPattern("d/M/yyyy"));
		System.out.println(hoyEspanya);
		DateTimeFormatter esDateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm:ss");
		DateTimeFormatter esDateFormatLargo = DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM 'de' yyyy 'a las' hh:mm:ss")
				.withLocale(new Locale("es","ES"));
		System.out.println(LocalDateTime.now().format(esDateFormat));
		System.out.println(LocalDateTime.now().format(esDateFormatLargo));
		String idiomaLocal = System.getProperty("user.language");
		String paisLocal = System.getProperty("user.country");
		DateTimeFormatter esDateFormatLargoSistema = DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM 'de' yyyy 'a las' hh:mm:ss")
				.withLocale(new Locale(idiomaLocal,paisLocal));
		System.out.println("Formato actual del sistema: " + idiomaLocal +"-"+ paisLocal);
		System.out.println(LocalDateTime.now().format(esDateFormatLargoSistema));
		System.out.println(LocalDateTime.now().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG).withLocale(new Locale(idiomaLocal,paisLocal))));		
		DateTimeFormatter esDateFormatLargoSistemaMejorada = DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM 'de' yyyy 'a las' hh:mm:ss").withLocale(new Locale(System.getProperty("user.language"),System.getProperty("user.country")));
	}
	
	

}
