package com.fran.fechas;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fran.fechas.utilidades.FechasUtils;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println(FechasUtils.obtenerFechaFormatoLargoPais("ES"));
        System.out.println(FechasUtils.devolverEdad("28/04/1971"));
        int edad = FechasUtils.MAYORIA_EDAD;
        List<String> fechas = new ArrayList(Arrays.asList("10/01/2000","01/05/2010", "03/05/2020"));
        System.out.println(FechasUtils.devolverFechaMayor(fechas));
    }
}
