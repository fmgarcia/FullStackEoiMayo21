package com.fran.hibernate2;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.fran.hibernate2.entidades.Autores;
import com.fran.hibernate2.entidades.Libros;

/**
 * Hello world!
 *
 */
public class App 
{
	
	static SessionFactory sessionFactory = null;
	static Session session = null;
	
	// Abre la sesión
	public static void tearUp() {
		sessionFactory = new Configuration().configure().buildSessionFactory();
		session = sessionFactory.openSession();
	}
	
	// Cierra la sesión
	public static void tearDown() {
		session.close();
	}
	
	public static void probarConexionBBDD() {
		if(session!=null) {
			System.out.println("Sesión abierta");
		} else {
			System.out.println("Fallo en la sesión");
		}
	}
	
	
	/*public static void mostrarLibros() {
		List<Libros> resultados = session.createQuery("from Libros").list();
		System.out.println("Imprimiendo los libros:");
		resultados.forEach(l->System.out.println(l.getId() + " " + l.getTitulo() + " de " + l.getAutores().getNombre()));		
	}*/
	
	public static void mostrarAutores() {
		List<Autores> resultados = session.createQuery("from Autores").list();
		System.out.println("Imprimiendo los autores:");
		
		for(Autores autor : resultados) {
			if (autor.getLibros().size()>0) {
				System.out.println(autor.getCod() + " " + autor.getNombre() + " ha escrito:");
				autor.getLibros().forEach(e -> System.out.println(e.getTitulo()));
			}
		}	
	}
	
	public static void mostrarLibros() {
		List<Libros> resultados = session.createQuery("from Libros").list();
		System.out.println("Imprimiendo los autores:");
		
		for(Libros resultado : resultados) {
			System.out.println(resultado.getId() + " " + resultado.getTitulo() + " ha sido escrito por:");
			resultado.getAutores().forEach(e->System.out.println(e.getNombre()));
		}	
	}
	
	public static void ejemploInsertar() {
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();  // abro la transacción
			// Creo un autor con libros
			Autores autornuevo = new Autores("5","EOI2",new HashSet<Libros>());
			Set<Libros> libros = new HashSet<Libros>();
			libros.add(new Libros(1));
			libros.add(new Libros(2));
			autornuevo.setLibros(libros);
			// Creo un libro con autores
			Set<Autores> autores = new HashSet<Autores>();
			autores.add(new Autores("1"));
			autores.add(new Autores("5"));
			Libros libronuevo = new Libros(11,"Libro de prueba",autores);
			// Guardado de los datos en la BBDD
			session.save(autornuevo);			
			session.save(libronuevo);
			// Confirmación de todos los cambios
			transaction.commit();
			System.out.println("Se ha creado el autor y el libro");
		} catch (Exception e) {
			transaction.rollback();	// Deshago todos los cambios
			System.out.println("Ha fallado el proceso de inserción de autor y libro");
		}		
	}
	
	public static void ejemploUpdate() {
		Transaction transaction = null;
		try {
			List<Libros> resultados = session.createQuery("from Libros where id=11").list();
			if(resultados.size()>0) {
				transaction = session.beginTransaction();  // abro la transacción
				Libros libroaModificar = resultados.get(0);
				libroaModificar.setTitulo("Título del libro modificado");
				Set<Autores> autores = new HashSet<Autores>();
				autores.add(new Autores("2"));
				autores.add(new Autores("4"));
				libroaModificar.setAutores(autores);
				session.update(libroaModificar);
				transaction.commit();
				System.out.println("Se ha actualizado el libro");
			}
		} catch (Exception e) {
			transaction.rollback();	// Deshago todos los cambios
			System.out.println("Ha fallado el proceso de actualización del libro");
		}		
	}
	
	public static void ejemploDelete() {
		Transaction transaction = null;
		try {
			List<Libros> resultados = session.createQuery("from Libros where id=11").list();
			if(resultados.size()>0) {
				transaction = session.beginTransaction();  // abro la transacción
				session.delete(resultados.get(0));
				transaction.commit();
				System.out.println("Se ha borrado el libro");
			}
		} catch (Exception e) {
			transaction.rollback();	// Deshago todos los cambios
			System.out.println("Ha fallado el proceso de borrado del libro");
		}	
	}
	
	
	public static void ejemploDelete2() {
		Transaction transaction = null;
		try {
			List<Libros> resultados = session.createQuery("from Libros where titulo like '%nual%'").list();  // HQL
			if(resultados.size()>0) {
				transaction = session.beginTransaction();  // abro la transacción
				resultados.forEach(e->session.delete(e));  // Eliminamos todos los resultados
				transaction.commit();
				System.out.println("Se han borrado todos los libros con ese criterio de búsqueda");
			}
		} catch (Exception e) {
			transaction.rollback();	// Deshago todos los cambios
			System.out.println("Ha fallado el proceso de borrado del libro/s");
		}	
	}
	
	@SuppressWarnings("unchecked")
	public static void ejemploDeleteConNativeQuery() {
		Transaction transaction = null;
		try {
			List<Autores> resultados = session.createNativeQuery("Select * from autores where cod= :codigo")
					.addEntity(Autores.class)
					.setParameter("codigo", "5")
					.list();			
			if(resultados.size()>0) {
				transaction = session.beginTransaction();  // abro la transacción
				resultados.forEach(e->session.delete(e));  // Eliminamos todos los resultados
				transaction.commit();
				System.out.println("Se han borrado todos los libros con ese criterio de búsqueda");
			}
		} catch (Exception e) {
			transaction.rollback();	// Deshago todos los cambios
			System.out.println("Ha fallado el proceso de borrado del libro/s");
		}	
	}
	
    public static void main( String[] args )
    {
    	@SuppressWarnings("unused")
    	org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
    	java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);
    	
    	tearUp();
    	//probarConexionBBDD();
    	//mostrarAutores();
    	//mostrarLibros();
    	//ejemploInsertar();
    	//ejemploUpdate();
    	//ejemploDelete();
    	//ejemploDelete2();
    	ejemploDeleteConNativeQuery();
    	tearDown();
    }
}
