package com.fran.ficheros;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fran.ficheros.auxiliares.Ficheros;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException
    {
        //Ficheros.crearFichero("c:/ficheroseoi", "fran.txt");
        //Ficheros.crearFichero("c:/ficheroseoiaaaa/franaaaaa.txt");
        //Ficheros.eliminarFichero("c:/ficheros", "fran.txt");
        //Ficheros.eliminarFichero("c:/ficherosprueba");
    	//Ficheros.renombrarFichero("c:/ficherosprueba", "fran.txt", "eoi.txt");
    	//Ficheros.moverPapelera("c:/ficherosprueba", "eoi.txt");
    	//Ficheros.leerDirectorio("c:/ficheros");
    	//String [] lista = Ficheros.obtenerDatosDirectorio("c:/ficheros");
    	//Ficheros.leerFicheroBufferedReader5("c:/ficheros", "cuentas.txt");
    	//Ficheros.leerFichero8("c:/ficheros", "cuentas.txt");
    	//Ficheros.buscarEnFichero("c:/ficheros", "cuentas.txt", "Fran").forEach(l->System.out.println(l));
    	//Ficheros.crearFichero8("/ficheros/fran2.txt");  
    	//Ficheros.agregarLineaFichero8("c:/ficheros/fran.txt", "Esta es la linea a añadir");
    	//Ficheros.limpiarFichero8("c:/ficheros/fran.txt");
    	/*List<String> lineas = new ArrayList<String>();
    	lineas.add("Hola mundo");
    	lineas.add("adiós mundo");
    	lineas.add("Me llamo Fran");
    	Ficheros.escribirFichero8("c:/ficheros/fran.txt", lineas);*/
    	//Ficheros.escribirFichero8("c:/ficheros/fran.txt", "Hola mundo","adiós mundo","Me llamo Fran","otra línea");
    	//Ficheros.escribirLineaFichero8("c:/ficheros/fran.txt", "Hola mundo");
    	Ficheros.copiarFichero8("c:/ficheros/fran.txt", "c:/ficheros/fran2.txt");
    }
}
