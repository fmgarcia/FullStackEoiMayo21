package com.fran.programacionfuncional;

import java.util.ArrayList;
import java.util.List;

public class EjemplosProgramacionFuncional {
	
	static List<Usuario> usuarios;
	
	public static void setUp() {
		usuarios = new ArrayList<Usuario>();
		Usuario u1 = new Usuario(1,"Fran",1000);
		usuarios.add(u1);
		usuarios.add(new Usuario(2,"Adrián",1500));
		usuarios.add(new Usuario(3,"José",1500));
		usuarios.add(new Usuario(4,"Adrián",1800));
		usuarios.add(new Usuario(5,"adrián",2500));
		usuarios.add(new Usuario(6,"Adrián",1500));
		usuarios.add(new Usuario(2,"Miguel",-1500));
	}
	
	public static void setDown() {
		usuarios.clear();
	}
	
	public static void eForEach() {
		setUp();
		/*for (int i = 0; i < usuarios.size(); i++) {
			System.out.println(usuarios.get(i));
		}*/
		/*for(Usuario usuario : usuarios) {
			System.out.println(usuario);
		}*/
		usuarios.forEach(u->System.out.println(u));
		//usuarios.stream().forEach(u->System.out.println(u));
		setDown();
	}
	
	public static void eFilter() {
		setUp();
		usuarios.stream()
			.filter(e->e.getSueldo()>1000)
			.filter(e->e.getId()>4)
			.forEach(e->System.out.println(e));
		setDown();
	}
	

}
