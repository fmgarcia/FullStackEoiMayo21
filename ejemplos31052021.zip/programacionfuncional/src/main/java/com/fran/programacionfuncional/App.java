package com.fran.programacionfuncional;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //EjemplosProgramacionFuncional.eForEach();
        EjemplosProgramacionFuncional.eFilter();
    }
}
