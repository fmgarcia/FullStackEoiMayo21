package com.fran.programacionfuncional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class EjemplosProgramacionFuncional {
	
	static List<Usuario> usuarios;
	
	public static void setUp() {
		usuarios = new ArrayList<Usuario>();
		Usuario u1 = new Usuario(2,"Fran",1000);
		usuarios.add(u1);
		usuarios.add(new Usuario(2,"Adrián",1500));
		usuarios.add(new Usuario(3,"José",1500));
		usuarios.add(new Usuario(1,"Adrián",1800));
		usuarios.add(new Usuario(5,"adrián",2500));
		usuarios.add(new Usuario(6,"Adrián",1500));
		usuarios.add(new Usuario(2,"Miguel",-1500));
	}
	
	public static void setDown() {
		usuarios.clear();
	}
	
	public static void eForEach() {
		setUp();
		/*for (int i = 0; i < usuarios.size(); i++) {
			System.out.println(usuarios.get(i));
		}*/
		/*for(Usuario usuario : usuarios) {
			System.out.println(usuario);
		}*/
		usuarios.forEach(u->System.out.println(u));
		//usuarios.stream().forEach(u->System.out.println(u));
		setDown();
	}
	
	public static void imprimirUsuario(Usuario u) {
		System.out.println(u.getNombre());
	}
	
	public static void eFilter() {
		setUp();
		// Mostrar por pantalla algunos elementos
		usuarios.stream()
			.filter(e->e.getNombre().equalsIgnoreCase("adrián"))
			.filter(e->e.getSueldo()>1000)
			.forEach(e->System.out.println(e));
			//.forEach(e->imprimirUsuario(e));
			//.forEach(System.out::println);
		
		/*List<Usuario> usuariosFiltro = new ArrayList<Usuario>();
		for(Usuario usuario : usuarios) {
			if(usuario.getNombre().equalsIgnoreCase("ádrian") && usuario.getSueldo()>1000) {
				usuariosFiltro.add(usuario);
			}
		}*/
					
		// Construir una sublista
		List<Usuario> usuariosFiltrados = usuarios.stream()
		.filter(e->e.getNombre().equalsIgnoreCase("adrián"))
		.filter(e->e.getSueldo()>1000)
		.collect(Collectors.toList());  // Crear nueva lista con los filtrados
		usuariosFiltrados.forEach(e->e.setNombre(e.getNombre().toUpperCase()));  // Pasar nombre a mayúscula
		System.out.println(usuarios.size());  // 7
		System.out.println(usuariosFiltrados.size());  // 4
		
		Usuario fran = new Usuario(10,"fran",1000);
		imprimirUsuario(fran);
		Usuario paco = new Usuario(10,"fran",1000);
		imprimirUsuario(paco);
		
		setDown();
	}
	
	public static void eMap() {
		setUp();
		// Map me permite quedarme con uno de los campos de la clase
		List<String> nombres = usuarios.stream()
				.map(e->e.getNombre())
				.collect(Collectors.toList());
		// Nos quedamos con una lista de nombres no repetidos
		Set<String> nombresNoRepetidos = usuarios.stream()
				.map(e->e.getNombre().toLowerCase())
				.collect(Collectors.toSet());
		
		System.out.println("**********");
		nombres.forEach(nombre->System.out.println(nombre));
		System.out.println("**********");
		nombresNoRepetidos.forEach(nombre->System.out.println(nombre));
		setDown();
	}
	
	public static void eFind() {
		setUp();
		// FindFirst: devuelve el primer objeto de la lista que cumpla un criterio
		Optional<Usuario> primerAdrian = usuarios.stream()
			.filter(e->e.getNombre().equalsIgnoreCase("Adriánnnnnn"))
			.findFirst();  // Encuentra el primero
		if(primerAdrian.isEmpty()) {
			System.out.println("No se han encontrado elementos en la búsqueda");
		}
		System.out.println(primerAdrian.isEmpty()?"No hay Adrián":primerAdrian.get().getNombre());
		
		Usuario otroAdrian = usuarios.stream()
				.filter(e->e.getNombre().equalsIgnoreCase("Adriánnnnnn"))
				.findFirst()
				.orElse(new Usuario(1,"Adrián",1000));  // Valor por defecto si no encuentro el primero de la lista
		System.out.println(otroAdrian.getNombre());

		Usuario otroAdrian2 = usuarios.stream()
				.filter(e->e.getNombre().equalsIgnoreCase("Adriánnnnnn"))
				.findFirst()
				.orElse(null);
		if(otroAdrian2!=null) {  // Ha encontrado alguno
			
		}		
		setDown();
	}
	
	public static void eFlatMap() {
		// FlatMap: Coge una lista de listas y las concatena e una lista única. Pasa de dos dimensiones a una  [][] -> []
	List<String> alumnosDam = new ArrayList<String>(Arrays.asList("Fran","Paco","Dani"));
	List<String> alumnosDaw = new ArrayList<String>(Arrays.asList("Adrián","Federico","Lorena"));
	
	List<List<String>> alumnos = new ArrayList<List<String>>(Arrays.asList(alumnosDam,alumnosDaw));
	/*alumnos.add(alumnosDaw);
	alumnos.add(alumnosDam);*/
	System.out.println(alumnos);
	
	List<String> todosAlumnos = alumnos.stream()
			.flatMap(e->e.stream())  // Fusiona las listas
			.sorted()				 // Ordena la lista lista nueva
			//.sorted(Comparator.reverseOrder())  // Ordena de mayor a menor
			.collect(Collectors.toList()); // Crea la lista
	todosAlumnos.forEach(e->System.out.println(e));	
	}
	
	public static void ePeek() {
		// Peek : Es equivalente al for-each pero sin ser final. Recorre todos los elementos de la lista
		setUp();
		List<Usuario> usuarios2 = usuarios.stream()
				.filter(e->!e.getNombre().equalsIgnoreCase("adrián"))
				.peek(u->u.setSueldo(u.getSueldo()+1000))
				.filter(usu->usu.getSueldo()>1500)
				.peek(u->u.setSueldo(u.getSueldo()+3000))
				.collect(Collectors.toList());

		System.out.println("*********");
		usuarios.forEach(u->System.out.println(u));
		System.out.println("*********");
		usuarios2.forEach(u->System.out.println(u));
		
		setDown();		
	}
	
	public static void eCount() {
		setUp();
		long numeroElementos = usuarios.stream()
				.filter(e->e.getNombre().equalsIgnoreCase("adrián"))
				.count();
		System.out.println(numeroElementos);  // 4
		System.out.println(usuarios.stream().filter(e->e.getNombre().equalsIgnoreCase("adrián")).count()); // 4
		setDown();
	}
	
	public static void eSkipLimit() {
		// Skip salta el número de elementos que digamos
		// Limit limita el número de resultados
		// No es obligatorio el uso combinado de ambos
		List<String> alumnos = new ArrayList<String>(Arrays.asList("Fran","Paco","Dani","Miguel","Ivan", "Jose","Pablo"));
		List<String> sublistaAlumnos =alumnos.stream()
			.sorted()
			.skip(2)
			.limit(3)
			.collect(Collectors.toList());
		sublistaAlumnos.forEach(e->System.out.println(e));
	}
	
	public static void eMaxMin() {
		setUp();
		Optional<Usuario> usuarioMinId	= usuarios.stream()
			.min(Comparator.comparing(Usuario::getId));
		System.out.println(!usuarioMinId.isEmpty()?usuarioMinId.get().getId():"No hay mínimo");
		Usuario usuarioMaxId = usuarios.stream()
				.max(Comparator.comparing(Usuario::getId))
				.orElse(new Usuario(1,"Fran",1000));
		System.out.println(usuarioMaxId.getId());
		setDown();
	}
	
	public static void eDistinct() {
		// Distinct: coge valores distintos
		setUp();
		/*List<String> nombresDistintos = usuarios.stream()
				.map(e->e.getNombre().toLowerCase())
				.distinct()
				.collect(Collectors.toList());
		nombresDistintos.forEach(e->System.out.println(e));*/
		usuarios.stream()
			.map(e->e.getSueldo())
			.distinct()
			.sorted()
			.forEach(e->System.out.println(e));
		
		setDown();
	}
	
	public static void eMatch() {
		// Devuelven un booleano : true o false
		// allMatch : true si todos cumplen la condicion
		// anyMatch: true si alguno cumple la condicion
		// noneMatch: true si ninguno cumple la condicion
		setUp();
			boolean algunoMas20000 = usuarios.stream()
			.anyMatch(e->e.getSueldo()>20000);
			boolean todosMas20000 = usuarios.stream()
					.allMatch(e->e.getSueldo()>20000);
			boolean ningunoMas20000 = usuarios.stream()
					.noneMatch(e->e.getSueldo()>20000);
			System.out.println(algunoMas20000); //  False
			System.out.println(todosMas20000);	// False
			System.out.println(ningunoMas20000); // True
			if(usuarios.stream().anyMatch(e->e.getSueldo()<0)) {
				usuarios.stream().filter(e->e.getSueldo()<0).forEach(e->System.out.println(e));
			}
			else {
				System.out.println("no hay quien gana menos de 0 euros");
			}
						
		setDown();
	}
	
	public static void eSumAverageRange() {
		setUp();
		
		double sumaSueldos = usuarios.stream()
			.mapToDouble(Usuario::getSueldo)
			.sum();		
		System.out.println("La suma de los sueldos es: " + sumaSueldos);
		double mediaSueldos = usuarios.stream()
				.mapToDouble(e->e.getSueldo())
				.average()
				.orElse(-1);
		System.out.println("La media es: " + mediaSueldos);
		
		// Crea una lista de números con los valores inicial y final
		IntStream.rangeClosed(1, 10).forEach(e->System.out.println(e + "*7=" + (e*7)));
		
		setDown();
	}
	
	public static void eReduce() {
		// Reduce : Reduce los datos que tengamos a un ÚNICO valor
		setUp();
		double sumaSueldos = usuarios.stream()
				.mapToDouble(e->e.getSueldo())
				.reduce(1000, (a,b)->a*b);
				//.reduce(0,Double::sum);
		System.out.println(sumaSueldos);
		setDown();
	}
	
	public static void eJoining() {
		// Joining: Permite unir elementos
		setUp();
		String nombresSeparados = usuarios.stream()
				.map(e->e.getNombre().toLowerCase())
				.distinct()
				.sorted()
				.collect(Collectors.joining(", ")).toString();
		System.out.println(nombresSeparados);
		setDown();
	}
	
	public static void eSet() {
		// Set : no permite elementos duplicados
		setUp();
		Set<String> nombresDistintos = usuarios.stream()
				.map(e->e.getNombre().toLowerCase())
				.collect(Collectors.toSet());
		setDown(); 
	}
	
	public static void eSummarizingDouble() {
		// Saca estadísticas de un campo numérico
		setUp();
		DoubleSummaryStatistics estadisticas = usuarios.stream()
				.collect(Collectors.summarizingDouble(Usuario::getSueldo));
		System.out.println("Media: " + estadisticas.getAverage());
		System.out.println("Máximo: " + estadisticas.getMax());
		System.out.println("Míximo: " + estadisticas.getMin());
		System.out.println("Suma: " + estadisticas.getSum());
		System.out.println("Cuenta: " + estadisticas.getCount());
		setDown(); 
	}
	
	public static void ePartitioningBy() {
		// PartitioningBy : Permite partir una lista en dos sublistas, una cumple la condicion y la otra no
		setUp();
		Map<Boolean,List<Usuario>> sueldosGrandes = usuarios.stream()
				.collect(Collectors.partitioningBy(e->e.getSueldo()>1500));
		System.out.println("Ganan mucho");
		sueldosGrandes.get(true).forEach(e->System.out.println(e));
		System.out.println("Ganan poco");
		sueldosGrandes.get(false).forEach(e->System.out.println(e));
		setDown();
	}
	
	public static void eGroupingBy() {
		setUp();
		Map<Character,List<Usuario>> listaLetras = usuarios.stream()
				.collect(Collectors.groupingBy(e-> new Character(e.getNombre().charAt(0))));
		System.out.println("Los que empiezan por A");
		listaLetras.get('A').forEach(e->System.out.println(e));
		System.out.println("Los que empiezan por M");
		listaLetras.get('M').forEach(e->System.out.println(e));		
		setDown();
	}
	
	private static String convertirMayusculas(String nombre) {
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return nombre.toUpperCase();
	}
	
	public static void eStreamParalelo() {
		setUp();
		long tiempo1 = System.currentTimeMillis();
		usuarios.stream().forEach(e->convertirMayusculas(e.getNombre()));
		long tiempo2 = System.currentTimeMillis();
		System.out.println("Tiempo normal: " + (tiempo2-tiempo1));
		tiempo1 = System.currentTimeMillis();
		usuarios.parallelStream().forEach(e->convertirMayusculas(e.getNombre()));
		tiempo2 = System.currentTimeMillis();
		System.out.println("Tiempo en paralelo: " + (tiempo2-tiempo1));
		setDown();
	}
	
	
}
