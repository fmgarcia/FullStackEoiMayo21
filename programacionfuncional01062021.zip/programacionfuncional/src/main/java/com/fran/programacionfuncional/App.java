package com.fran.programacionfuncional;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //EjemplosProgramacionFuncional.eForEach();
        //EjemplosProgramacionFuncional.eFilter();
    	//EjemplosProgramacionFuncional.eMap();
    	//EjemplosProgramacionFuncional.eFind();
    	//EjemplosProgramacionFuncional.eFlatMap();
        //EjemplosProgramacionFuncional.ePeek();
    	//EjemplosProgramacionFuncional.eCount();
    	//EjemplosProgramacionFuncional.eSkipLimit();
    	//EjemplosProgramacionFuncional.eMaxMin();
    	//EjemplosProgramacionFuncional.eDistinct();
    	//EjemplosProgramacionFuncional.eMatch();
    	//EjemplosProgramacionFuncional.eSumAverageRange();
    	//EjemplosProgramacionFuncional.eReduce();
    	//EjemplosProgramacionFuncional.eJoining();
    	//EjemplosProgramacionFuncional.eSummarizingDouble();
    	//EjemplosProgramacionFuncional.ePartitioningBy();
    	//EjemplosProgramacionFuncional.eGroupingBy();
    	//EjemplosProgramacionFuncional.eStreamParalelo();
  	
    }
}
