package com.fran.xmljson.utilidades;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fran.xmljson.entidades.Noticia;
import com.fran.xmljson.entidades.People;
import com.fran.xmljson.entidades.Tarea;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JsonUtils {
	
	/**
	 * Recibe una url en formato cadena y devuelve el contenido de esa Url como una cadena
	 * @param web la cadena que almacena la url
	 * @return	Todo el contenido de esa url en un String
	 */
	public static String readUrl(String web) {
		try {
			URL url = new URL(web);
			URLConnection uc = url.openConnection();			
			uc.setRequestProperty("User-Agent", "PostmanRuntime/7.20.1");
			uc.connect();
			String lines = new BufferedReader(
					new InputStreamReader(uc.getInputStream(), 
							StandardCharsets.UTF_8))
					.lines()
					.collect(Collectors.joining());
			//System.out.println(lines);
			return lines;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha podido la leer la URL: " + web);
		}
		return null;
	}
	
	public static String readUrl(String web, String token) {
		try {
			URL url = new URL(web);
			URLConnection uc = url.openConnection();			
			uc.setRequestProperty("User-Agent", "PostmanRuntime/7.20.1");
			uc.setRequestProperty("X-Auth-Token", token);
			uc.connect();
			String lines = new BufferedReader(
					new InputStreamReader(uc.getInputStream(), 
							StandardCharsets.UTF_8))
					.lines()
					.collect(Collectors.joining());
			//System.out.println(lines);
			return lines;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha podido la leer la URL: " + web);
		}
		return null;
	}
	
	public static void apiJsonSimpleFichero(String rutaCompleta) {
		
		try {
			// parseado del fichero que le pasemos como parámetro
			Object obj = new JSONParser().parse(new FileReader(rutaCompleta));
			// castear Object -> JSONObject
			JSONObject jo = (JSONObject) obj;
			
			// Lectura de los tipos de datos simples
			String nombre = (String) jo.get("nombre");  // codger variable nombre
			String apellido = (String) jo.get("apellido");
			long edad = (long) jo.get("edad");
			System.out.println("El nombre es: " + nombre + " y el apellido: " + apellido + " con edad: " + edad);
			
			// Lectura de los tipos de datos compuestos
			Map domicilio = (Map) jo.get("domicilio");
			Iterator<Map.Entry> iterador = domicilio.entrySet().iterator();
			iterador.forEachRemaining(e->System.out.println(e.getKey() + ": " + e.getValue()));
			
			// Como tratar los arrays
			JSONArray ja = (JSONArray) jo.get("numerosTelefonos");
			Iterator numeros = ja.iterator();
			numeros.forEachRemaining(e->{
				Iterator<Map.Entry> campos = ((Map)e).entrySet().iterator();
				campos.forEachRemaining(campo->System.out.println(campo.getKey() + ": " + campo.getValue()));
			});
					
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	public static void apiJsonSimpleInternet(String url) {	
		// Este ejemplo me vale si me encuentro con un Json
		// que directamente es un array (no lleva las llevas como comienzo del json) directamente lleva los corchetes
		try {
			String cadena = readUrl(url);	
			// parseado de la cadena que contiene el Json
			Object obj = new JSONParser().parse(cadena);						
			// Como tratar los arrays
			JSONArray ja = (JSONArray) obj;
			Iterator numeros = ja.iterator();
			numeros.forEachRemaining(e->{
				Iterator<Map.Entry> campos = ((Map)e).entrySet().iterator();
				campos.forEachRemaining(campo->System.out.println(campo.getKey() + ": " + campo.getValue()));
			});					
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	public static List<Tarea> devolverApiJsonSimpleInternet(String url) {	
		// Este ejemplo me vale si me encuentro con un Json
		// que directamente es un array (no lleva las llevas como comienzo del json) directamente lleva los corchetes
		List<Tarea> resultado = new ArrayList<Tarea>();
		try {
			String cadena = readUrl(url);	
			// parseado de la cadena que contiene el Json
			Object obj = new JSONParser().parse(cadena);						
			// Como tratar los arrays
			JSONArray ja = (JSONArray) obj;
			Iterator elementos = ja.iterator();
			elementos.forEachRemaining(e->{
				JSONObject elementoObjeto = (JSONObject)e;
				resultado.add(new Tarea(
						(long)elementoObjeto.get("userId"),
						(long)elementoObjeto.get("id"),
						(String)elementoObjeto.get("title"),
						(boolean)elementoObjeto.get("completed")
						));
			});					
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return resultado;
	}
	
	/**
	 * Dado una url devuelve un objeto de tipo People con el contenido de esa url
	 * @param url
	 * @return
	 */
	public static People devolverPeopleGson(String url) {
		String cadena = readUrl(url);
		Gson gson = new Gson();
		People personaje = gson.fromJson(cadena, People.class);
		return personaje;
	}
	
	public static <T> T devolverGenericGson(String url, Class<T> clase) {
		String cadena = readUrl(url);
		if (cadena!=null) {
			Gson gson = new Gson();
			T resultado = gson.fromJson(cadena, clase);
			return resultado;
		} else {
			return null;
		}
	}
	
	public static <T> List<T> devolverListaGenericGson(String urlBase,Class<T> clase, int numeroElementos, String cadenaAdicional){
		List<T> resultado = new ArrayList<T>();
		for(int i=1;i<=numeroElementos;i++) {
			T elemento = devolverGenericGson(urlBase+i+cadenaAdicional,clase);
			if(elemento!=null) {
				resultado.add(elemento);
			}
		}
		return resultado;
	}
	
	public static void debeDevolverJSONEnUnProperties() {
		final String json = "{\"id\":46,\"nombre\":\"Fran\",\"empresa\":\"EOI\"}";
		final Gson gson = new Gson();
	    final Properties properties = gson.fromJson(json, Properties.class);
	    System.out.println(properties.getProperty("id"));
	    System.out.println(properties.getProperty("nombre"));
	    System.out.println(properties.getProperty("empresa"));
	    System.out.println(properties.getProperty("propiedadInexistente"));
	}
	
	//Escribir un Json
	public static void escribirJson() {
		Noticia noticia = new Noticia("Título de la noticia", "noticia de prueba","hola","adiós","mundo cruel");
		Gson gson = new Gson();
		String json = gson.toJson(noticia);
		System.out.println(json);
	}
	
	//Escribir un Json Bonito
	public static void escribirJsonBonito() {
		Noticia noticia = new Noticia("Título de la noticia", "noticia de prueba","hola","adiós","mundo cruel");
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(noticia);
		System.out.println(json);
	}
	
	public static <T> String escribirJsonBonitoGenerico(T objeto) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(objeto);
		return json;
	}

}
