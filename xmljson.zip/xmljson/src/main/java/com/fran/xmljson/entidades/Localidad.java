package com.fran.xmljson.entidades;

import java.util.ArrayList;
import java.util.List;

public class Localidad {

	private String codigo;
	private String localidad;
	private String provincia;
	private List<Dia> prediccion;
	
	public Localidad() {
		prediccion = new ArrayList<Dia>();
	}

	public Localidad(String codigo, String localidad, String provincia, List<Dia> prediccion) {
		super();
		this.codigo = codigo;
		this.localidad = localidad;
		this.provincia = provincia;
		this.prediccion = prediccion;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getLocalidad() {
		return localidad;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public List<Dia> getPrediccion() {
		return prediccion;
	}

	public void setPrediccion(List<Dia> prediccion) {
		this.prediccion = prediccion;
	}

	@Override
	public String toString() {
		return "Localidad [codigo=" + codigo + ", localidad=" + localidad + ", provincia=" + provincia + ", prediccion="
				+ prediccion + "]";
	}
	
	
	
	
}
