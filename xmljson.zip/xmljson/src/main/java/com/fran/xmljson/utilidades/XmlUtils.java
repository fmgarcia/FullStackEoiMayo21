package com.fran.xmljson.utilidades;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.fran.xmljson.entidades.Dia;
import com.fran.xmljson.entidades.Localidad;
import com.fran.xmljson.entidades.Noticia;

public class XmlUtils {

	public static void leerXmlAsignaturas(String rutaCompleta) {
		try {
			// Estas lineas serian iguales en todos los proyectos
			File inputFile = new File(rutaCompleta);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			// Cosas particulares de este Xml concreto
			System.out.println("Elemento base: " + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("asignatura"); // Crea una lista con los elementos del Xml que se
																		// llamen igual que la cadena pasada
			System.out.println("Recorriendo asignaturas...");
			for (int i = 0; i < nList.getLength(); i++) {
				Node nNode = nList.item(i);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode; // Voy a ir cogiendo las asignaturas de una en una
					System.out.println("Id: " + eElement.getAttribute("id"));
					System.out.println("Nombre: " + eElement.getElementsByTagName("nombre").item(0).getTextContent());
					System.out.println("Ciclo Formativo: "
							+ eElement.getElementsByTagName("cicloFormativo").item(0).getTextContent());
					System.out.println("Curso: " + eElement.getElementsByTagName("curso").item(0).getTextContent());
					System.out
							.println("Profesor: " + eElement.getElementsByTagName("profesor").item(0).getTextContent());
				}
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void leerXmlInternetMarca(String urlCadena) {
		URL url = null;
		try {
			// Estas lineas serian iguales en todos los proyectos
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			url = new URL(urlCadena);
			Document doc = dBuilder.parse(url.openStream());
			doc.getDocumentElement().normalize();
			// Cosas particulares de este Xml concreto
			NodeList nList = doc.getElementsByTagName("item"); // Crea una lista con los elementos del Xml que se llamen
																// igual que la cadena pasada
			for (int i = 0; i < nList.getLength(); i++) {
				Node nNode = nList.item(i);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode; // Voy a ir cogiendo las asignaturas de una en una
					System.out.println("Noticia: " + eElement.getElementsByTagName("title").item(0).getTextContent());
				}
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static List<Noticia> devolverNoticiasXmlInternetMarca(String urlCadena) {
		List<Noticia> lista = new ArrayList<Noticia>();
		URL url = null;
		try {
			// Estas lineas serian iguales en todos los proyectos
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			url = new URL(urlCadena);
			Document doc = dBuilder.parse(url.openStream());
			doc.getDocumentElement().normalize();
			// Cosas particulares de este Xml concreto
			NodeList nList = doc.getElementsByTagName("item"); // Crea una lista con los elementos del Xml que se llamen
																// igual que la cadena pasada
			for (int i = 0; i < nList.getLength(); i++) {
				Node nNode = nList.item(i);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode; // Voy a ir cogiendo las asignaturas de una en una
					lista.add(new Noticia(eElement.getElementsByTagName("title").item(0).getTextContent(),
							eElement.getElementsByTagName("description").item(0).getTextContent(),
							eElement.getElementsByTagName("link").item(0).getTextContent(),
							eElement.getElementsByTagName("guid").item(0).getTextContent(),
							eElement.getElementsByTagName("pubDate").item(0).getTextContent()));
				}
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;
	}
	
	public static Localidad devolverLocalidadXmlInternetAemet(String urlCadena) {
		Localidad localidad = new Localidad();
		String codigo = urlCadena.substring(urlCadena.indexOf('_')+1, urlCadena.indexOf('_')+6);
		localidad.setCodigo(codigo);
		URL url = null;
		try {
			// Estas lineas serian iguales en todos los proyectos
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			url = new URL(urlCadena);
			Document doc = dBuilder.parse(url.openStream());
			doc.getDocumentElement().normalize();
			// Cosas particulares de este Xml concreto
			localidad.setLocalidad(doc.getElementsByTagName("nombre").item(0).getTextContent()); 
			localidad.setProvincia(doc.getElementsByTagName("provincia").item(0).getTextContent()); 

			NodeList nList = doc.getElementsByTagName("dia");
			for (int i = 0; i < nList.getLength(); i++) {
				Node nNode = nList.item(i);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode; // Voy a ir cogiendo las asignaturas de una en una
					Dia dia;
					if(eElement.getElementsByTagName("prob_precipitacion").getLength()>=3)
					{		
						dia = new Dia(eElement.getAttribute("fecha"),
						Integer.parseInt(eElement.getElementsByTagName("prob_precipitacion").item(0).getTextContent()),
						Integer.parseInt(eElement.getElementsByTagName("prob_precipitacion").item(1).getTextContent()),
						Integer.parseInt(eElement.getElementsByTagName("prob_precipitacion").item(2).getTextContent())
						);
					}else {
						dia = new Dia(eElement.getAttribute("fecha"),
						Integer.parseInt(eElement.getElementsByTagName("prob_precipitacion").item(0).getTextContent()),
						Integer.parseInt(eElement.getElementsByTagName("prob_precipitacion").item(0).getTextContent()),
						Integer.parseInt(eElement.getElementsByTagName("prob_precipitacion").item(0).getTextContent())
						);

					}
					localidad.getPrediccion().add(dia);
				}
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return localidad;
	}
	

}
