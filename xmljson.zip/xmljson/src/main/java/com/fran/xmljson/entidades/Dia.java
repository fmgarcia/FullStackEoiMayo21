package com.fran.xmljson.entidades;

public class Dia {

	private String fecha;
	private int prob_precipacion00_24;
	private int prob_precipacion00_12;
	private int prob_precipacion12_24;
	
	public Dia() {
		
	}

	public Dia(String fecha, int prob_precipacion00_24, int prob_precipacion00_12, int prob_precipacion12_24) {
		super();
		this.fecha = fecha;
		this.prob_precipacion00_24 = prob_precipacion00_24;
		this.prob_precipacion00_12 = prob_precipacion00_12;
		this.prob_precipacion12_24 = prob_precipacion12_24;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public int getProb_precipacion00_24() {
		return prob_precipacion00_24;
	}

	public void setProb_precipacion00_24(int prob_precipacion00_24) {
		this.prob_precipacion00_24 = prob_precipacion00_24;
	}

	public int getProb_precipacion00_12() {
		return prob_precipacion00_12;
	}

	public void setProb_precipacion00_12(int prob_precipacion00_12) {
		this.prob_precipacion00_12 = prob_precipacion00_12;
	}

	public int getProb_precipacion12_24() {
		return prob_precipacion12_24;
	}

	public void setProb_precipacion12_24(int prob_precipacion12_24) {
		this.prob_precipacion12_24 = prob_precipacion12_24;
	}

	@Override
	public String toString() {
		return "Dia [fecha=" + fecha + ", prob_precipacion00_24=" + prob_precipacion00_24 + ", prob_precipacion00_12="
				+ prob_precipacion00_12 + ", prob_precipacion12_24=" + prob_precipacion12_24 + "]";
	}


		
}
