package com.fran.xmljson;

import java.util.ArrayList;
import java.util.List;

import com.fran.xmljson.entidades.Localidad;
import com.fran.xmljson.entidades.Noticia;
import com.fran.xmljson.utilidades.JsonUtils;
import com.fran.xmljson.utilidades.XmlUtils;

public class App 
{
    public static void main( String[] args )
    {
        //XmlUtils.leerXmlAsignaturas("asignaturas.xml");
    	//XmlUtils.leerXmlInternetMarca("https://e00-marca.uecdn.es/rss/futbol/primera-division.xml");
    	//XmlUtils.leerXmlInternetMarca("https://www.sport.es/es/rss/barca/rss.xml");
    	//List<Noticia> noticiasMarca = XmlUtils.devolverNoticiasXmlInternetMarca("https://e00-marca.uecdn.es/rss/futbol/primera-division.xml");
    	/*noticiasMarca.stream()
    		.filter(e->e.getDescription().contains("Real"))
    		.forEach(e->System.out.println("Título: " + e.getTitle() + "\n" + e.getDescription()));
    	*/
    	/*Localidad alcoy = XmlUtils.devolverLocalidadXmlInternetAemet("http://www.aemet.es/xml/municipios/localidad_03009.xml");	
    	System.out.println(alcoy);*/
    	JsonUtils.apiJsonSimpleFichero("ejemplo.json");
    	
    }
}
