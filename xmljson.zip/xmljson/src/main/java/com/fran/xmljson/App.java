package com.fran.xmljson;

import java.util.ArrayList;
import java.util.List;

import com.fran.xmljson.entidades.Localidad;
import com.fran.xmljson.entidades.Noticia;
import com.fran.xmljson.entidades.Tarea;
import com.fran.xmljson.utilidades.JsonUtils;
import com.fran.xmljson.utilidades.XmlUtils;

public class App 
{
	
	public static void recogerTareasInternet() {
		List<Tarea> listaTareas = JsonUtils.devolverApiJsonSimpleInternet("https://jsonplaceholder.typicode.com/todos");
		listaTareas.stream()
		.filter(t->t.isCompleted()==true)
		.forEach(t->System.out.println(t));
	}
	
    public static void main( String[] args )
    {
    	
    	// Métodos de XML
        //XmlUtils.leerXmlAsignaturas("asignaturas.xml");
    	//XmlUtils.leerXmlInternetMarca("https://e00-marca.uecdn.es/rss/futbol/primera-division.xml");
    	//XmlUtils.leerXmlInternetMarca("https://www.sport.es/es/rss/barca/rss.xml");
    	//List<Noticia> noticiasMarca = XmlUtils.devolverNoticiasXmlInternetMarca("https://e00-marca.uecdn.es/rss/futbol/primera-division.xml");
    	/*noticiasMarca.stream()
    		.filter(e->e.getDescription().contains("Real"))
    		.forEach(e->System.out.println("Título: " + e.getTitle() + "\n" + e.getDescription()));
    	*/
    	/*Localidad alcoy = XmlUtils.devolverLocalidadXmlInternetAemet("http://www.aemet.es/xml/municipios/localidad_03009.xml");	
    	System.out.println(alcoy);*/
    	
    	// Métodos de JSON
    	//JsonUtils.apiJsonSimpleFichero("ejemplo.json");
    	//System.out.println(JsonUtils.readUrl("https://api.covid19tracking.narrativa.com/api/2021-01-01/country/france"));
    	//JsonUtils.apiJsonSimpleInternet("https://jsonplaceholder.typicode.com/todos");
    	recogerTareasInternet();
    }
}
