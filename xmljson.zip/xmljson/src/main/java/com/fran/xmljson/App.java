package com.fran.xmljson;

import java.util.ArrayList;
import java.util.List;

import com.fran.xmljson.entidades.Localidad;
import com.fran.xmljson.entidades.Noticia;
import com.fran.xmljson.entidades.People;
import com.fran.xmljson.entidades.Tarea;
import com.fran.xmljson.utilidades.JsonUtils;
import com.fran.xmljson.utilidades.XmlUtils;



public class App 
{
	
	public static void recogerTareasInternet() {
		List<Tarea> listaTareas = JsonUtils.devolverApiJsonSimpleInternet("https://jsonplaceholder.typicode.com/todos");
		listaTareas.stream()
		.filter(t->t.isCompleted()==true)
		.forEach(t->System.out.println(t));
	}
	
	public static void probarLeerPeople() {
		People personaje = JsonUtils.devolverPeopleGson("https://swapi.dev/api/people/1/?format=json");
		System.out.println(personaje);
	}
	
	public static void probarLeerGenerico() {
		People personaje = JsonUtils.devolverGenericGson("https://swapi.dev/api/people/1000/?format=json",People.class);
		System.out.println(personaje);		
	}
	
	public static void probarListaGenericaGson() {
		List<People> personajes = JsonUtils.devolverListaGenericGson("https://swapi.dev/api/people/", People.class, 100, "/?format=json");
		//personajes.forEach(p->System.out.println(p));
		personajes.stream()
		.filter(p->p.getHair_color().equals("blond"))
		.forEach(p->System.out.println(p));
	}
	
	public static void probarProperties() {
		JsonUtils.debeDevolverJSONEnUnProperties();
	}
	
	public static void probarEscribirJson() {
		JsonUtils.escribirJson();
	}
	
	public static void probarEscribirJsonBonito() {
		JsonUtils.escribirJsonBonito();
	}
	
	
	
	
    public static void main( String[] args )
    {
    	
    	// Métodos de XML
        //XmlUtils.leerXmlAsignaturas("asignaturas.xml");
    	//XmlUtils.leerXmlInternetMarca("https://e00-marca.uecdn.es/rss/futbol/primera-division.xml");
    	//XmlUtils.leerXmlInternetMarca("https://www.sport.es/es/rss/barca/rss.xml");
    	//List<Noticia> noticiasMarca = XmlUtils.devolverNoticiasXmlInternetMarca("https://e00-marca.uecdn.es/rss/futbol/primera-division.xml");
    	/*noticiasMarca.stream()
    		.filter(e->e.getDescription().contains("Real"))
    		.forEach(e->System.out.println("Título: " + e.getTitle() + "\n" + e.getDescription()));
    	*/
    	/*Localidad alcoy = XmlUtils.devolverLocalidadXmlInternetAemet("http://www.aemet.es/xml/municipios/localidad_03009.xml");	
    	System.out.println(alcoy);*/
    	
    	// Métodos de JSON
    	//JsonUtils.apiJsonSimpleFichero("ejemplo.json");
    	//System.out.println(JsonUtils.readUrl("https://api.covid19tracking.narrativa.com/api/2021-01-01/country/france"));
    	//JsonUtils.apiJsonSimpleInternet("https://jsonplaceholder.typicode.com/todos");
    	//recogerTareasInternet();
    	//probarLeerPeople();
    	//probarLeerGenerico();
    	//probarListaGenericaGson();
    	//probarProperties();
    	//probarEscribirJson();
    	probarEscribirJsonBonito();
    }
}
