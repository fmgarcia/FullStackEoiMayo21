package com.fran.jdbc.ejemplos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EoiMySql {
	
	private static final String url = "jdbc:mysql://localhost:3306/eoi?serverTimezone=UTC";
	private static final String usuario = "root";
	private static final String password = "";
	
	
	public static void probarConexion() {
		// Utilizamos la interfaz Autocloseable
		try(Connection con = DriverManager.getConnection(url, usuario, password)){
			System.out.println("La conexión se realizó satisfactoriamente");
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public static void selectBasica(String sql) {
		try(Connection con = DriverManager.getConnection(url, usuario, password);
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql)){
			// System.out.println("Oficina Ciudad Region");
			// Nos vamos a mover por los resultados
			while(rs.next()) {
				System.out.println(rs.getLong("oficina") + " " + rs.getString("ciudad") + " " + rs.getString("region"));
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void selectStatementScroll(String sql) {
		try(Connection con = DriverManager.getConnection(url, usuario, password);
			Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = st.executeQuery(sql)){
			rs.afterLast(); // me muevo al final del todo
			while(rs.previous()) {
				System.out.println(rs.getLong("oficina") + " " + rs.getString("ciudad") + " " + rs.getString("region"));
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void selectStatementModificable(String sql) {
		try(Connection con = DriverManager.getConnection(url, usuario, password);
			Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = st.executeQuery(sql)){
			rs.absolute(4);  // Me muevo a la fila 4 (empieza por la 1)
			rs.updateString("ciudad", "EOI"); // actualizo un campo
			rs.updateRow();	// guardo la fila actual
			System.out.println("La fila ha sido actualizada");
			System.out.println(rs.getLong("oficina") + " " + rs.getString("ciudad") + " " + rs.getString("region"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void selectStatementConInsercion(String sql) {
		try(Connection con = DriverManager.getConnection(url, usuario, password);
				Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = st.executeQuery(sql)){
				rs.moveToInsertRow();
				rs.updateLong("dir", 101);
				rs.updateLong("objetivo", 100000);
				rs.updateLong("ventas", 200000);
				rs.updateLong("oficina", 100);
				rs.updateString("region", "Region EOI");
				rs.updateString("ciudad", "Ciudad EOI"); // actualizo un campo
				rs.insertRow();	// guardo la fila actual
				System.out.println("La fila ha sido insertada");
				rs.last();
				System.out.println(rs.getLong("oficina") + " " + rs.getString("ciudad") + " " + rs.getString("region"));
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	public static void selectStatementBorrado(String sql) {
		try(Connection con = DriverManager.getConnection(url, usuario, password);
			Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = st.executeQuery(sql)){
			rs.last();  // Me muevo a la última fila
			rs.deleteRow();  // Elimina la fila
			System.out.println("La fila ha sido borrada");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void selectPreparedStatement() {
		try(Connection con = DriverManager.getConnection(url, usuario, password);
			PreparedStatement ps = con.prepareStatement("Select * from oficinas where region = ? and ciudad = ?")){
			ps.setString(1, "Este"); // Con esto evitamos Sql injection
			ps.setString(2, "Alicante");
			try(ResultSet rs = ps.executeQuery()){
				while(rs.next()) {
					System.out.println(rs.getLong("oficina") + " " + rs.getString("ciudad") + " " + rs.getString("region"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}
	
	
	
	public static void main(String[] args) {
		//probarConexion();
		//selectBasica("Select * from oficinas");
		//selectStatementScroll("Select * from oficinas");
		//selectStatementModificable("Select * from oficinas");
		//selectStatementConInsercion("Select * from oficinas");
		//selectStatementBorrado("Select * from oficinas");
		selectPreparedStatement();
	}
	
	

}
