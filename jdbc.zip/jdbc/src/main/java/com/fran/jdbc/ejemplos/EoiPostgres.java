package com.fran.jdbc.ejemplos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.fran.jdbc.utilidades.JdbcUtils;

public class EoiPostgres {
	
	private static final String url = "jdbc:postgresql://localhost:5432/eventos";
	private static final String usuario = "postgres";
	private static final String password = "postgres";
	
	private static Connection con = null;
	private static Statement st = null;
	
	public static void probarConexion() {
		// Utilizamos la interfaz Autocloseable
		try(Connection con = DriverManager.getConnection(url, usuario, password)){
			System.out.println("La conexión se realizó satisfactoriamente");
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public static void probarConexion2() {
		try {
			Class.forName("org.postgresql.Driver");  // Ya no es obligatorio, pero lo podemos encontrar por ahí.
			Connection con = DriverManager.getConnection(url, usuario, password);
			System.out.println("La conexión se realizó satisfactoriamente");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void conexion() {
		try {
			con = DriverManager.getConnection(url, usuario, password);
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void desconexion() {
		try {
			st.close();
			con.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static String devolverNombreEvento() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca el nombre del evento:");
		String nombreEvento = sc.nextLine();
		return nombreEvento;
	}
	
	public static void selectBasica(String sql) {
		ResultSet rs = null;
		try {
			rs = st.executeQuery(sql);
			int registros = 0;
			while(rs.next()) {
				registros++;
				System.out.println(rs.getLong("id") + " " + rs.getString("nombre") + " " + rs.getString("descripcion"));
				/*if(rs.isLast())
					System.out.println("El total de registros es: " + rs.getRow());*/
			}
			System.out.println("El total de registros es: " + registros);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void insertRegistroTabla(String sql) {
		try {
			int numerofilas = st.executeUpdate(sql);
			System.out.println("La insert se ejecutó correctamente con " + numerofilas + ((numerofilas==1)?" fila":" filas"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void borrarRegistroTabla(String sql) {
		try {
			int numerofilas = st.executeUpdate(sql);
			if(numerofilas>0)
				System.out.println("El delete se ejecutó correctamente con " + numerofilas + ((numerofilas==1)?" fila":" filas"));
			else
				System.out.println("No hay filas que cumplen el criterio de borrado");			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void modificarRegistroTabla(String sql) {
		try {
			int numerofilas = st.executeUpdate(sql);
			if(numerofilas>0)
				System.out.println("El update se ejecutó correctamente con " + numerofilas + ((numerofilas==1)?" fila":" filas"));
			else
				System.out.println("No hay filas que cumplen el criterio de modificación");			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void modificarRegistroTablaPreparedStatement(String sql) {		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca el identificador a modificar:");
		int identificador = Integer.parseInt(sc.nextLine());
		System.out.println("Introduzca el nuevo nombre del evento:");
		String nombreEvento = sc.nextLine();
		PreparedStatement ps = null;
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, nombreEvento);
			ps.setInt(2, identificador);
			int numerofilas = ps.executeUpdate();
			if(numerofilas>0)
				System.out.println("El update se ejecutó correctamente con " + numerofilas + ((numerofilas==1)?" fila":" filas"));
			else
				System.out.println("No hay filas que cumplen el criterio de modificación");			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// Con esto evitamos sql injection
	public static void selectPreparedStatement(String sql, String nombreEvento) {	
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			//ps.setString(1, nombreEvento);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				System.out.println(rs.getLong("id") + " " + rs.getString("nombre") + " " + rs.getString("descripcion"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public static void probarStatementGenerico() {
		ResultSet rs = JdbcUtils.statementGenerico("Select * from evento", con, url, usuario, password);
		try {
			while(rs.next()) {
				System.out.println(rs.getLong("id") + " " + rs.getString("nombre") + " " + rs.getString("descripcion"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		//probarConexion();
		//probarConexion2();
		conexion();
		//selectBasica("Select * from evento");
		//insertRegistroTabla("INSERT INTO evento(nombre,descripcion,precio,fecha) VALUES ('fullstack Java2','ejemplo insert',11.50,'27/07/2021'),('fullstack Java3','ejemplo insert',11.50,'27/07/2021');");
		//borrarRegistroTabla("DeLeTe from evento WHERE nombre='fullstack Java'");
		//modificarRegistroTabla("UPDATE evento SET precio = precio + 10 WHERE nombre LIKE '%t%2%';");
		//modificarRegistroTablaPreparedStatement("UPDATE evento SET nombre=? WHERE id=?");
		// commit->confirmar una/s operación
		// rollback-> deshacer una/s operción
		// Select * from evento where nombre='a' or '1'='1'
		// a' or '1'='1  es lo usado para sql injection en cadenas
		// 1 or 1=1 o  1 or '1'='1' sería usado en campos numéricos
		//selectBasica("Select * from evento where nombre='" + devolverNombreEvento() + "'" );
		//selectPreparedStatement("Select * from evento where nombre=?",devolverNombreEvento());
		//selectPreparedStatement("Select * from evento where nombre='evento 1'","kk");
		probarStatementGenerico();
		desconexion();
		
	}
	
	

}
