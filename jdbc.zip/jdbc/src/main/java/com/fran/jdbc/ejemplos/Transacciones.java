package com.fran.jdbc.ejemplos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Transacciones {

	private static final String url = "jdbc:mysql://localhost:3306/eoi2?serverTimezone=UTC";
	private static final String usuario = "root";
	private static final String password = "";
	
	public static void ejemploTransaccion() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, usuario, password);
			con.setAutoCommit(false); // Deshabilitamos el auto commit de la base de datos
			Statement st = con.createStatement();
			st.executeUpdate("INSERT INTO oficinas(oficina,ciudad,region) VALUES(34,'EOI','Este')");
			st.executeUpdate("INSERT INTO dptoficinas(codigo,departamento,oficina,telefono) VALUES(201,1,35,'666.666.666')");
			con.commit();
			System.out.println("La transacción se ejecutó correctamente");
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				con.rollback();
				System.out.println("La transacción no pudo ejecutarse");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}		
	}

	public static void main(String[] args) {
		ejemploTransaccion();
	}
	
	
}
