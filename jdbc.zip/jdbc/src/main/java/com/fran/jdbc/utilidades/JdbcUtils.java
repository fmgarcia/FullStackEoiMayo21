package com.fran.jdbc.utilidades;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class JdbcUtils {
	
	public static ResultSet statementGenerico(String sql, Connection con, String url, String usuario, String password) {
		ResultSet rs = null;
		try{
			con = DriverManager.getConnection(url, usuario, password);
			Statement st = con.createStatement();
			rs = st.executeQuery(sql);	
			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	private static ResultSet preparedStatementGenerico(String sql, Connection con, String url, String usuario, String password,List<String> valorParametros) {
		ResultSet rs = null;
		try{
			con = DriverManager.getConnection(url, usuario, password);
			int numeroParametros = StringUtils.compareIgnoreCase(sql, "?");
			if(numeroParametros>valorParametros.size()) // Faltan interrogaciones sin datos
				return null;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}
