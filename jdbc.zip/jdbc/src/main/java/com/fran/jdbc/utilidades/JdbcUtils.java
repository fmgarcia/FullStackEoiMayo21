package com.fran.jdbc.utilidades;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class JdbcUtils {
	
	private static final String url = "jdbc:postgresql://localhost:5432/eventos";
	private static final String usuario = "postgres";
	private static final String password = "postgres";
	
	private static Connection con = null;
	
	
	public static Connection openConnection() {
		try {
			con = DriverManager.getConnection(url, usuario, password);
			return con;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static void closeConnection(Connection con) {
		try {
			con.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static ResultSet statementGenerico(String sql, Connection con) {
		ResultSet rs = null;
		try{
			con = DriverManager.getConnection(url, usuario, password);
			Statement st = con.createStatement();
			rs = st.executeQuery(sql);	
			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static ResultSet preparedStatementGenerico(String sql, Connection con, List<Object> valorParametros) {
		ResultSet rs = null;
		try{
			con = DriverManager.getConnection(url, usuario, password);
			int numeroParametros = StringUtils.countMatches(sql, "?");
			if(numeroParametros>valorParametros.size()) // Faltan interrogaciones sin datos
				return null;
			PreparedStatement ps = con.prepareStatement(sql);
			for(int i=1;i<=numeroParametros;i++) {
				if(valorParametros.get(i-1) instanceof String)
					ps.setString(i, (String) valorParametros.get(i-1)); // La lista el primer elemento es el 0
				if(valorParametros.get(i-1) instanceof Integer)
					ps.setInt(i, (Integer) valorParametros.get(i-1)); // La lista el primer elemento es el 0
			}
			rs =ps.executeQuery();
			return rs;			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}
