package com.fran.hibernate1;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.internal.build.AllowSysOut;
import org.hibernate.query.Query;

import com.fran.hibernate1.entidades.Autores;
import com.fran.hibernate1.entidades.Libros;

/**
 * Hello world!
 *
 */
public class App 
{
	static SessionFactory sessionFactory = null;
	static Session session = null;
	
	// Abre la sesión
	public static void tearUp() {
		sessionFactory = new Configuration().configure().buildSessionFactory();
		session = sessionFactory.openSession();
	}
	
	// Cierra la sesión
	public static void tearDown() {
		session.close();
	}
	
	public static void probarConexionBBDD() {
		if(session!=null) {
			System.out.println("Sesión abierta");
		} else {
			System.out.println("Fallo en la sesión");
		}
	}
	
	public static void mostrarLibros() {
		/*Query<Libros> consulta = session.createQuery("from Libros"); // Lenguaje HQL
		List<Libros> resultados = consulta.list();*/
		List<Libros> resultados = session.createQuery("from Libros").list();
		System.out.println("Imprimiendo los libros:");
		resultados.forEach(l->System.out.println(l.getId() + " " + l.getTitulo() + " de " + l.getAutores().getNombre()));		
	}
	
	public static void mostrarAutores() {
		List<Autores> resultados = session.createQuery("from Autores").list();
		System.out.println("Imprimiendo los autores:");
		
		for(Autores autor : resultados) {
			System.out.println(autor.getCod() + " " + autor.getNombre() + " ha escrito:");
			autor.getLibroses().forEach(e->System.out.println(e.getTitulo()));
		}	
	}
	
    public static void main( String[] args )
    {
    	@SuppressWarnings("unused")
    	org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
    	java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);
    	tearUp();
    	//probarConexionBBDD();
    	//mostrarLibros();
    	mostrarAutores();
    	tearDown();
    }
}
